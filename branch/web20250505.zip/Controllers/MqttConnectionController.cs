using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/MqttConnection")]  // 修改這行，確保與客戶端請求的路徑一致
public class MqttConnectionController : ControllerBase
{
    private readonly MqttClientConnectionManager _connectionManager;

    public MqttConnectionController(MqttClientConnectionManager connectionManager)
    {
        _connectionManager = connectionManager;
    }

    [HttpGet("clients")]
    public async Task<IActionResult> GetClients()
    {
        var clients = await _connectionManager.mqttServer.GetClientsAsync();

        var result = clients.Select(c => new
        {
            c.Id,
            c.RemoteEndPoint,
            c.ProtocolVersion,
            c.ConnectedTimestamp,
            c.LastPacketSentTimestamp,
            c.LastPacketReceivedTimestamp,
            c.Session,
        });

        return Ok(result);
    }

    [HttpGet("sessions")]
    public async Task<IActionResult> GetSessions()
    {
        var clients = await _connectionManager.mqttServer.GetSessionsAsync();

        var result = clients.Select(c => new
        {
            c.Id,
            c.CreatedTimestamp,
            c.DisconnectedTimestamp,
            c.ExpiryInterval,
            c.Items
        });

        return Ok(result);
    }

    [HttpGet]
    [Route("status")]
    public IActionResult GetAllConnectionStatus()
    {
        var clients = _connectionManager.GetAllClients();
        return Ok(clients);
    }

    [HttpGet]
    [Route("status/{clientId}")]
    public IActionResult GetConnectionStatus(string clientId)
    {
        var client = _connectionManager.GetClient(clientId);
        if (client == null)
        {
            return NotFound($"Client with ID {clientId} not found");
        }
        return Ok(client);
    }
}