using System.Collections.Concurrent;
using MQTTnet.Server;

public class MqttClientConnectionManager
{
    public MqttServer mqttServer;
    private readonly ConcurrentDictionary<string, ClientConnectionInfo> _clients = new();

    public void AddOrUpdateClient(MqttServer mqttServer,string clientId, bool isConnected)
    {
        _clients.AddOrUpdate(
            clientId,
            new ClientConnectionInfo 
            { 
                ClientId = clientId, 
                IsConnected = isConnected, 
                LastUpdated = DateTime.UtcNow 
            },
            (_, existing) => 
            {
                existing.IsConnected = isConnected;
                existing.LastUpdated = DateTime.UtcNow;
                return existing;
            });
    }

    public IEnumerable<ClientConnectionInfo> GetAllClients()
    {
        return _clients.Values.ToList();
    }

    public ClientConnectionInfo GetClient(string clientId)
    {
        if (_clients.TryGetValue(clientId, out var info))
        {
            return info;
        }
        return null;
    }
}

public class ClientConnectionInfo
{
    public string ClientId { get; set; }
    public bool IsConnected { get; set; }
    public DateTime LastUpdated { get; set; }
}