using MQTTnet.AspNetCore;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using MQTTnet.Server;

//https://www.cnblogs.com/zxtceq/articles/18432765

var builder = WebApplication.CreateBuilder(args);

//builder.Logging.ClearProviders();
// 添加控制器支持
builder.Services.AddControllers();
// 添加Swagger支持
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//AddHostedMqttServer
builder.Services.AddHostedMqttServer(mqttServer =>
{
    mqttServer.WithoutDefaultEndpoint();
})
    .AddMqttConnectionHandler()
    .AddConnections();

//Config Port
builder.WebHost.UseKestrel(option =>
{
    //option.ListenAnyIP(1883, l => l.UseMqtt());
    option.ListenAnyIP(5443, listenOptions =>
    {
        // 設定 HTTPS
        listenOptions.UseHttps(httpsOptions =>
        {
            // 使用開發憑證
            // 生產環境中需要替換為正式 TLS 憑證
            httpsOptions.ServerCertificate = new System.Security.Cryptography.X509Certificates.X509Certificate2(
                Path.Combine(builder.Environment.ContentRootPath, "certificate.pfx"), "yourpassword");
        });
    });
});

// Add services to the container.
// 添加MQTT客户端连接管理器作为单例服务
builder.Services.AddSingleton<MqttClientConnectionManager>();

//builder.Services.AddControllers();

var app = builder.Build();
// 配置HTTP请求管道
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure the HTTP request pipeline.

// 添加控制器端點映射
//app.MapControllers();

// 添加靜態檔案支援
app.UseStaticFiles();

//Websocket Mqtt
app.UseRouting();

app.UseEndpoints(endpoints =>
{
    //MqttServerWebSocket
    endpoints.MapConnectionHandler<MqttConnectionHandler>("/mqtt", options =>
    {
        options.WebSockets.SubProtocolSelector = MqttSubProtocolSelector.SelectSubProtocol;
    });
    // 添加控制器端點映射
    endpoints.MapControllers();
    
});

MqttClientConnectionManager connectionManager;
// Retrieve the singleton instance
connectionManager = app.Services.GetRequiredService<MqttClientConnectionManager>();



app.UseMqttServer(
    server =>
    {
        connectionManager.mqttServer = server;
        /*
            * Attach event handlers etc. if required.
            */

        server.ValidatingConnectionAsync += async e => 
            {
                connectionManager.AddOrUpdateClient(server,e.ClientId, true);
                await Task.CompletedTask;
            };

        server.ClientConnectedAsync += async e => 
            {
                connectionManager.AddOrUpdateClient(server,e.ClientId, true);
                await Task.CompletedTask;
            };
        server.ClientDisconnectedAsync += async e => 
            {
                connectionManager.AddOrUpdateClient(server,e.ClientId, false);
                await Task.CompletedTask;
            };
    });

    
//app.UseHttpsRedirection();

//app.UseAuthorization();

app.Run();
