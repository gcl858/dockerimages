# 銀行臨櫃業務 SOP 導覽系統技術文件

## 1. DOM 結構分析

### 1.1 頁面主要區塊
```mermaid
graph TD
    A[HTML Document] --> B[Header 區塊]
    A --> C[主要內容區]
    A --> D[系統狀態區]
    
    C --> E[Tab 導航]
    C --> F[Tab 內容區]
    
    F --> G[開戶業務]
    F --> H[匯款業務]
    F --> I[存款提領]
    
    D --> J[狀態訊息框]
    D --> K[顯示狀態按鈕]
```

### 1.2 重要元素結構與屬性
- 頁面標題：`<header class="header text-center mb-4">`
- 主容器：`<div class="main-container">`
- 業務分類標籤列：`<ul class="nav nav-tabs mb-4" id="businessTabs">`
- 業務內容區：`<div class="tab-content" id="businessTabContent">`
- 系統狀態框：`<div id="status-box">`

## 2. CSS 樣式分析

### 2.1 全局樣式
```css
body {
    background-color: #f8f9fa;
    padding-bottom: 100px;
}
```

### 2.2 主要元件樣式
1. **頁面標題樣式**
```css
.header {
    background-color: #0d6efd;
    color: white;
    padding: 1rem;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
```

2. **主容器樣式**
```css
.main-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}
```

3. **導航標籤樣式**
```css
.nav-tabs .nav-link {
    color: #495057;
    font-weight: 500;
}

.nav-tabs .nav-link.active {
    color: #0d6efd;
    font-weight: 600;
}
```

4. **手風琴樣式**
```css
.accordion-button:not(.collapsed) {
    background-color: #e7f1ff;
    color: #0d6efd;
}
```

### 2.3 狀態訊息框樣式
```css
#status-box {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: #212529;
    color: white;
    z-index: 1030;
    transition: height 0.3s;
}
```

## 3. JavaScript 功能實現

### 3.1 事件監聽器設置
```javascript
document.addEventListener('DOMContentLoaded', function() {
    // 初始化系統狀態時間
    // 綁定狀態框控制事件
    // 設置表單數據收集
});
```

### 3.2 主要功能模組
1. **狀態訊息管理**
   - 時間戳更新：`new Date().toLocaleString()`
   - 顯示/隱藏控制：通過 `style.display` 切換
   - 大小調整：使用 `mousedown`, `mousemove`, `mouseup` 事件

2. **表單數據處理**
   ```javascript
   forms.forEach(form => {
       const inputs = form.querySelectorAll('input');
       inputs.forEach(input => {
           input.addEventListener('change', function() {
               const fieldName = this.id;
               const fieldValue = this.type === 'checkbox' ? this.checked : this.value;
           });
       });
   });
   ```

## 4. 外部資源相依性

### 4.1 CSS 框架
- Bootstrap 5.3.0
  ```html
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  ```

### 4.2 圖標庫
- Bootstrap Icons 1.10.5
  ```html
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
  ```

### 4.3 JavaScript 庫
- Bootstrap Bundle 5.3.0（含 Popper）
  ```html
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  ```

## 5. 技術重點說明

### 5.1 響應式設計實現
- 使用 Bootstrap 的網格系統
- 自適應容器寬度（max-width: 1200px）
- 移動端友好的互動元素

### 5.2 互動功能實現
1. **標籤頁切換**
   - 使用 Bootstrap 的 Tab 組件
   - 資料屬性：`data-bs-toggle="tab"`

2. **手風琴展開/收合**
   - 使用 Bootstrap 的 Accordion 組件
   - 資料屬性：`data-bs-toggle="collapse"`

3. **狀態訊息框**
   - 可拖曳調整大小
   - 顯示/隱藏切換
   - 自動更新時間戳

### 5.3 表單處理
- 多個獨立表單：
  - 法人開戶表單
  - 國內匯款表單
  - 現金提領表單
- 統一的數據收集機制
- 支援文本輸入和複選框

## 6. 優化建議

### 6.1 效能優化
1. **資源載入**
   - 考慮將 Bootstrap 相關資源本地化
   - 實施資源的延遲加載

2. **JavaScript 優化**
   - 減少事件監聽器數量
   - 使用事件委派優化表單處理

### 6.2 代碼優化
1. **樣式優化**
   - 提取共用樣式變數
   - 整合重複的樣式定義

2. **功能擴展**
   - 添加表單驗證
   - 實現數據持久化
   - 增加錯誤處理機制

### 6.3 可訪問性優化
- 完善 ARIA 標籤
- 增強鍵盤導航支持
- 改善顏色對比度