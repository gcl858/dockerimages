# 銀行臨櫃業務 SOP 導覽系統技術文件

## 1. 網頁架構分析

### 1.1 基本架構
```mermaid
graph TD
  A[HTML Document] --> B[Head]
  A --> C[Body]
  B --> B1[Meta Tags]
  B --> B2[External CSS]
  B --> B3[Custom CSS]
  C --> D[Header]
  C --> E[Main Container]
  C --> F[Status Box]
  E --> G[Business Tabs]
  G --> H[Account Tab]
  G --> I[Transfer Tab]
  G --> J[Deposit Tab]
```

### 1.2 主要DOM結構
- `<header class="header">`: 頁面標題區
- `<div class="main-container">`: 主要內容區
  - `<ul class="nav nav-tabs">`: 業務分類標籤
  - `<div class="tab-content">`: 標籤內容區
    - 各業務類型的手風琴(Accordion)組件
- `<div id="status-box">`: 系統狀態訊息框
  - `<div id="resize-handle">`: 可調整大小的控制器
  - `<div class="status-header">`: 狀態框標題
  - `<div class="status-body">`: 狀態訊息內容

### 1.3 重要元素結構
```mermaid
graph TD
  A[Tab Content] --> B[Accordion]
  B --> C[Accordion Item]
  C --> D[Accordion Header]
  C --> E[Accordion Body]
  E --> F[作業流程]
  E --> G[表單區域]
  G --> H[Form Inputs]
```

## 2. CSS樣式設定

### 2.1 外部樣式庫
- Bootstrap 5 CSS
- Bootstrap Icons

### 2.2 自訂樣式分類
1. **基礎布局樣式**
   ```css
   body { 
     background-color: #f8f9fa;
     padding-bottom: 100px;
   }
   .main-container {
     max-width: 1200px;
     margin: 0 auto;
   }
   ```

2. **主題樣式**
   ```css
   .header {
     background-color: #0d6efd;
     color: white;
   }
   ```

3. **導航樣式**
   ```css
   .nav-tabs .nav-link {
     color: #495057;
     font-weight: 500;
   }
   ```

4. **狀態框樣式**
   ```css
   #status-box {
     position: fixed;
     bottom: 0;
     background-color: #212529;
     color: white;
   }
   ```

## 3. JavaScript功能與互動邏輯

### 3.1 主要功能模塊
1. **狀態訊息管理**
   - 時間戳更新
   - 顯示/隱藏控制
   - 尺寸調整功能

2. **表單處理**
   - 輸入值變更監聽
   - 數據收集與驗證

### 3.2 事件處理
```mermaid
flowchart LR
  A[DOM載入] --> B[初始化時間戳]
  A --> C[綁定事件監聽器]
  C --> D[狀態框控制]
  C --> E[表單處理]
  D --> F[顯示/隱藏]
  D --> G[尺寸調整]
```
以@/bank-sop-guide-bootstrap.html 內容產出技術文檔，檔名為tech.md
## 4. 外部相依資源

### 4.1 CSS資源
- Bootstrap 5.3.0
  ```html
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  ```
- Bootstrap Icons 1.10.5
  ```html
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
  ```

### 4.2 JavaScript資源
- Bootstrap Bundle 5.3.0 (包含 Popper)
  ```html
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  ```

## 5. 技術重點注意事項

### 5.1 響應式設計
- 使用Bootstrap的網格系統
- 自適應容器寬度設定
- 移動設備友好的互動元素

### 5.2 可訪問性考慮
- ARIA標籤的正確使用
- 鍵盤導航支持
- 良好的語義化HTML結構

### 5.3 程式碼組織
- 模塊化的CSS結構
- 清晰的JavaScript事件處理
- 統一的命名規範

## 6. 效能優化與維護建議

### 6.1 效能優化建議
1. **資源優化**
   - 考慮將Bootstrap和Icons改為本地託管
   - 實施CSS和JavaScript的最小化
   - 添加適當的緩存策略

2. **渲染優化**
   - 避免不必要的DOM操作
   - 使用CSS transform代替位置調整
   - 實作lazy loading機制

### 6.2 維護建議
1. **代碼重構機會**
   - 將JavaScript邏輯模塊化
   - 建立統一的樣式變數
   - 實施錯誤處理機制

2. **功能擴展建議**
   - 添加表單驗證功能
   - 實現數據持久化
   - 增加操作記錄功能

### 6.3 監控與測試
- 添加錯誤日誌記錄
- 實施性能監控
- 建立自動化測試案例

## 7. 安全性考慮

### 7.1 資料安全
- 表單數據加密傳輸
- 輸入驗證與清理
- XSS防護措施

### 7.2 操作安全
- 用戶權限控制
- 操作日誌記錄
- 敏感數據保護