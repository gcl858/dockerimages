// 主程式入口
class BankSOPApp {
    constructor() {
        this.tabManager = null;
        this.accordionManager = null;
        this.statusBoxManager = null;
        this.initialize();
    }

    // 初始化應用程式
    initialize() {
        // 等待 DOM 載入完成
        document.addEventListener('DOMContentLoaded', () => {
            this.initializeManagers();
            this.setupEventListeners();
            this.showWelcomeMessage();
        });

        // 處理未捕獲的錯誤
        window.onerror = (msg, url, lineNo, columnNo, error) => {
            this.handleError(msg, url, lineNo, columnNo, error);
            return false;
        };

        // 處理 Promise 錯誤
        window.addEventListener('unhandledrejection', (event) => {
            this.handleError('未處理的 Promise 錯誤', null, null, null, event.reason);
        });
    }

    // 初始化各管理器
    initializeManagers() {
        try {
            // 初始化標籤管理器
            this.tabManager = window.tabManager;
            if (!this.tabManager) {
                throw new Error('標籤管理器初始化失敗');
            }

            // 初始化手風琴管理器
            this.accordionManager = window.accordionManager;
            if (!this.accordionManager) {
                throw new Error('手風琴管理器初始化失敗');
            }

            // 初始化狀態訊息框管理器
            this.statusBoxManager = window.statusBoxManager;
            if (!this.statusBoxManager) {
                throw new Error('狀態訊息框管理器初始化失敗');
            }

            // 更新系統狀態
            this.updateSystemStatus('所有模組初始化完成', 'success');
        } catch (error) {
            this.handleError('初始化失敗', null, null, null, error);
        }
    }

    // 設置事件監聽
    setupEventListeners() {
        // 監聽標籤切換事件
        document.addEventListener('tabContentLoaded', (event) => {
            const { tabId, service } = event.detail;
            this.updateSystemStatus(`已切換至${service.name}`, 'info');
        });

        // 監聽手風琴展開/收合事件
        document.addEventListener('shown.bs.collapse', (event) => {
            if (event.target.classList.contains('accordion-collapse')) {
                const itemId = event.target.id;
                const itemTitle = event.target.querySelector('.accordion-body')
                    ?.closest('.accordion-item')
                    ?.querySelector('.accordion-button')
                    ?.textContent.trim();
                
                if (itemTitle) {
                    this.updateSystemStatus(`已展開「${itemTitle}」的作業流程`, 'info');
                }
            }
        });

        // 監聽表單提交事件
        document.addEventListener('submit', (event) => {
            if (event.target.closest('.sop-form')) {
                event.preventDefault();
                this.handleFormSubmit(event.target);
            }
        });

        // 監聽視窗載入完成事件
        window.addEventListener('load', () => {
            this.updateSystemStatus('系統載入完成，可以開始操作', 'success');
        });
    }

    // 顯示歡迎訊息
    showWelcomeMessage() {
        const welcomeMessages = [
            '歡迎使用銀行臨櫃業務 SOP 導覽系統',
            '系統已就緒，請選擇要查看的業務類型',
            '如需協助請聯繫 IT 支援'
        ];

        let delay = 0;
        welcomeMessages.forEach((message) => {
            setTimeout(() => {
                this.updateSystemStatus(message, 'primary');
            }, delay);
            delay += 1000;
        });
    }

    // 處理表單提交
    handleFormSubmit(form) {
        const formData = new FormData(form);
        const formId = form.id;
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }

        // 這裡可以添加表單驗證邏輯
        this.validateAndProcessForm(formId, data);
    }

    // 驗證並處理表單
    validateAndProcessForm(formId, data) {
        // 模擬表單處理
        setTimeout(() => {
            this.updateSystemStatus(`表單「${formId}」處理完成`, 'success');
            console.log('表單數據：', data);
        }, 500);
    }

    // 更新系統狀態
    updateSystemStatus(message, type = 'info') {
        if (this.statusBoxManager) {
            this.statusBoxManager.updateStatus(message, type);
        }
    }

    // 處理錯誤
    handleError(msg, url, lineNo, columnNo, error) {
        const errorMessage = `錯誤：${msg}${lineNo ? ` (行號：${lineNo})` : ''}`;
        console.error(errorMessage, error);
        this.updateSystemStatus(errorMessage, 'danger');
    }
}

// 初始化應用程式
const app = new BankSOPApp();

// 導出全域實例
window.bankSOPApp = app;