// 業務分類標籤頁管理
class TabManager {
    constructor() {
        this.currentTab = 'account'; // 預設顯示開戶業務
        this.tabs = Object.keys(bankServices);
        this.initializeTabs();
        this.loadTabContent(this.currentTab);
    }

    // 初始化標籤頁
    initializeTabs() {
        // 清空並重建標籤頁
        const tabList = document.getElementById('businessTabs');
        tabList.innerHTML = '';
        
        // 建立各業務分類的標籤
        this.tabs.forEach((tabId, index) => {
            const service = bankServices[tabId];
            const li = document.createElement('li');
            li.className = 'nav-item';
            li.setAttribute('role', 'presentation');
            
            li.innerHTML = `
                <button class="nav-link ${index === 0 ? 'active' : ''}" 
                        id="${tabId}-tab"
                        data-bs-toggle="tab" 
                        data-bs-target="#${tabId}" 
                        type="button" 
                        role="tab"
                        aria-controls="${tabId}"
                        aria-selected="${index === 0}">
                    ${service.name}
                </button>
            `;
            
            tabList.appendChild(li);
        });

        // 建立標籤內容容器
        const tabContent = document.getElementById('businessTabContent');
        tabContent.innerHTML = '';
        
        this.tabs.forEach((tabId, index) => {
            const div = document.createElement('div');
            div.className = `tab-pane fade ${index === 0 ? 'show active' : ''}`;
            div.id = tabId;
            div.setAttribute('role', 'tabpanel');
            div.setAttribute('aria-labelledby', `${tabId}-tab`);
            
            // 建立手風琴容器
            div.innerHTML = `
                <div class="accordion" id="${tabId}Accordion">
                    <!-- 內容將由 AccordionManager 動態生成 -->
                </div>
            `;
            
            tabContent.appendChild(div);
        });

        // 監聽標籤切換事件
        this.setupTabEventListeners();
    }

    // 設置標籤切換事件監聽
    setupTabEventListeners() {
        const tabElements = document.querySelectorAll('[data-bs-toggle="tab"]');
        tabElements.forEach(tab => {
            tab.addEventListener('show.bs.tab', (event) => {
                const targetId = event.target.getAttribute('data-bs-target').replace('#', '');
                this.loadTabContent(targetId);
            });
        });
    }

    // 載入標籤內容
    loadTabContent(tabId) {
        this.currentTab = tabId;
        const service = bankServices[tabId];
        if (!service) return;

        // 觸發內容載入事件
        const event = new CustomEvent('tabContentLoaded', {
            detail: {
                tabId: tabId,
                service: service
            }
        });
        document.dispatchEvent(event);
    }

    // 取得當前選中的標籤
    getCurrentTab() {
        return this.currentTab;
    }

    // 切換到指定標籤
    switchToTab(tabId) {
        if (this.tabs.includes(tabId)) {
            const tab = document.querySelector(`#${tabId}-tab`);
            if (tab) {
                tab.click();
            }
        }
    }
}

// 當 DOM 載入完成後初始化 TabManager
document.addEventListener('DOMContentLoaded', () => {
    window.tabManager = new TabManager();
});