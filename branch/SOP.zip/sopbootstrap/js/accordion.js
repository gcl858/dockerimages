// 業務項目手風琴面板管理
class AccordionManager {
    constructor() {
        this.currentAccordion = null;
        this.setupEventListeners();
    }

    // 設置事件監聽
    setupEventListeners() {
        // 監聽標籤內容載入事件
        document.addEventListener('tabContentLoaded', (event) => {
            const { tabId, service } = event.detail;
            this.renderAccordion(tabId, service);
        });
    }

    // 渲染手風琴面板
    renderAccordion(tabId, service) {
        const accordion = document.getElementById(`${tabId}Accordion`);
        if (!accordion || !service.items) return;

        this.currentAccordion = accordion;
        accordion.innerHTML = ''; // 清空現有內容

        // 生成各業務項目的手風琴面板
        service.items.forEach((item, index) => {
            const accordionItem = this.createAccordionItem(tabId, item, index);
            accordion.appendChild(accordionItem);
        });
    }

    // 創建手風琴項目
    createAccordionItem(tabId, item, index) {
        const div = document.createElement('div');
        div.className = 'accordion-item';
        
        const headerId = `${item.id}Header`;
        const contentId = `${item.id}Content`;
        
        div.innerHTML = `
            <h2 class="accordion-header" id="${headerId}">
                <button class="accordion-button ${index > 0 ? 'collapsed' : ''}" 
                        type="button" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#${contentId}"
                        aria-expanded="${index === 0}"
                        aria-controls="${contentId}">
                    ${item.title}
                </button>
            </h2>
            <div id="${contentId}"
                 class="accordion-collapse collapse"
                 aria-labelledby="${headerId}">
                <div class="accordion-body">
                    ${this.renderItemContent(item)}
                </div>
            </div>
        `;

        return div;
    }

    // 渲染項目內容
    renderItemContent(item) {
        let content = '<div class="sop-content">';
        
        // 渲染 SOP 步驟
        if (item.steps && item.steps.length > 0) {
            content += `
                <h5 class="mb-3">作業步驟：</h5>
                <ol class="sop-steps">
                    ${item.steps.map(step => `<li>${step}</li>`).join('')}
                </ol>
            `;
        }

        // 渲染表單（如果有）
        if (item.forms && item.forms.length > 0) {
            item.forms.forEach(form => {
                content += this.renderForm(form);
            });
        }

        // 添加提示信息（如果有特殊要求）
        if (item.tips) {
            content += `
                <div class="tip-box mt-3">
                    ${item.tips}
                </div>
            `;
        }

        content += '</div>';
        return content;
    }

    // 渲染表單
    renderForm(form) {
        return `
            <div class="sop-form mt-4">
                <h5 class="mb-3">${form.label}：</h5>
                <form id="${form.id}Form">
                    ${form.fields.map(field => `
                        <div class="form-group">
                            <label for="${form.id}-${this.slugify(field)}">${field}：</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="${form.id}-${this.slugify(field)}"
                                   name="${this.slugify(field)}"
                                   placeholder="請輸入${field}">
                        </div>
                    `).join('')}
                </form>
            </div>
        `;
    }

    // 將中文字段名轉換為合法的 ID
    slugify(text) {
        return text
            .toString()
            .toLowerCase()
            .replace(/\s+/g, '-')
            .replace(/[^\w\-]+/g, '')
            .replace(/\-\-+/g, '-')
            .replace(/^-+/, '')
            .replace(/-+$/, '');
    }

    // 展開指定的項目
    expandItem(itemId) {
        const accordion = document.querySelector(`#${itemId}Content`);
        if (accordion) {
            const bsCollapse = new bootstrap.Collapse(accordion, {
                show: true
            });
        }
    }

    // 收合指定的項目
    collapseItem(itemId) {
        const accordion = document.querySelector(`#${itemId}Content`);
        if (accordion) {
            const bsCollapse = new bootstrap.Collapse(accordion, {
                hide: true
            });
        }
    }
}

// 當 DOM 載入完成後初始化 AccordionManager
document.addEventListener('DOMContentLoaded', () => {
    window.accordionManager = new AccordionManager();
});