// 系統狀態訊息框管理
class StatusBoxManager {
    constructor() {
        this.statusBox = document.getElementById('statusBox');
        this.statusContent = document.getElementById('statusContent');
        this.closeButton = document.getElementById('closeStatus');
        this.showButton = document.getElementById('showStatus');
        this.isDragging = false;
        this.startY = 0;
        this.startHeight = 0;
        this.currentHeight = 60; // 預設高度

        this.initializeStatusBox();
    }

    // 初始化狀態訊息框
    initializeStatusBox() {
        // 設置初始高度
        this.statusBox.style.height = `${this.currentHeight}px`;

        // 設置關閉按鈕事件
        this.closeButton.addEventListener('click', () => this.hideStatusBox());

        // 設置顯示按鈕事件
        this.showButton.addEventListener('click', () => this.showStatusBox());

        // 設置拖曳調整高度功能
        this.setupDragResize();

        // 設置視窗調整事件
        window.addEventListener('resize', () => this.handleWindowResize());
    }

    // 設置拖曳調整高度功能
    setupDragResize() {
        const dragArea = this.statusBox.querySelector(':scope > .container');

        dragArea.addEventListener('mousedown', (e) => {
            // 只在上方 20px 區域啟動拖曳
            if (e.offsetY <= 20) {
                this.startDragging(e);
            }
        });

        document.addEventListener('mousemove', (e) => this.handleDragging(e));
        document.addEventListener('mouseup', () => this.stopDragging());

        // 觸控設備支援
        dragArea.addEventListener('touchstart', (e) => {
            if (e.target === dragArea) {
                this.startDragging(e.touches[0]);
            }
        });

        document.addEventListener('touchmove', (e) => this.handleDragging(e.touches[0]));
        document.addEventListener('touchend', () => this.stopDragging());
    }

    // 開始拖曳
    startDragging(e) {
        this.isDragging = true;
        this.startY = e.clientY;
        this.startHeight = this.currentHeight;
    }

    // 處理拖曳過程
    handleDragging(e) {
        if (!this.isDragging) return;

        const deltaY = this.startY - e.clientY;
        let newHeight = this.startHeight + deltaY;
        // 限制高度範圍
        newHeight = Math.max(60, Math.min(window.innerHeight * 0.8, newHeight));
        this.currentHeight = newHeight;
        this.statusBox.style.height = `${newHeight}px`;
    }

    // 停止拖曳
    stopDragging() {
        this.isDragging = false;
        document.body.style.cursor = '';
    }

    // 處理視窗調整
    handleWindowResize() {
        // 確保狀態框不會超出視窗高度
        const maxHeight = window.innerHeight * 0.8;
        if (this.currentHeight > maxHeight) {
            this.currentHeight = maxHeight;
            this.statusBox.style.height = `${maxHeight}px`;
        }
    }

    // 隱藏狀態訊息框
    hideStatusBox() {
        this.statusBox.classList.add('collapsed');
        this.showButton.classList.remove('d-none');
    }

    // 顯示狀態訊息框
    showStatusBox() {
        this.statusBox.classList.remove('collapsed');
        this.showButton.classList.add('d-none');
    }

    // 更新狀態訊息
    updateStatus(message, type = 'info') {
        const statusContent = document.getElementById('statusContent');
        const timestamp = new Date().toLocaleTimeString('zh-TW');
        
        const messageElement = document.createElement('p');
        messageElement.className = `mb-2 text-${type}`;
        messageElement.innerHTML = `[${timestamp}] ${message}`;

        // 在開頭插入新訊息
        if (statusContent.firstChild) {
            statusContent.insertBefore(messageElement, statusContent.firstChild);
        } else {
            statusContent.appendChild(messageElement);
        }

        // 限制訊息數量，保留最新的 50 條
        const messages = statusContent.getElementsByTagName('p');
        if (messages.length > 50) {
            statusContent.removeChild(messages[messages.length - 1]);
        }

        // 如果訊息框是收起的，顯示提示動畫
        if (this.statusBox.classList.contains('collapsed')) {
            this.showButton.classList.add('animate__animated', 'animate__bounce');
            setTimeout(() => {
                this.showButton.classList.remove('animate__animated', 'animate__bounce');
            }, 1000);
        }
    }

    // 清空狀態訊息
    clearStatus() {
        const statusContent = document.getElementById('statusContent');
        statusContent.innerHTML = '';
    }
}

// 當 DOM 載入完成後初始化 StatusBoxManager
document.addEventListener('DOMContentLoaded', () => {
    window.statusBoxManager = new StatusBoxManager();
});