DWORD CHostMessage::MyEMessageRecv(LPBYTE lpbySentence, DWORD SentenceLength)

{

	CmTradeJournal* lpCmTradeJournal;	// Journal Object Pointer

    CcKeyHardCopy*	lpCcKeyHardCopy;

	CTrWindowsAP*	lpCTrWindowsAP;

	DWORD		dwGetEventId;

	DWORD		dwGetEventKey;

	DWORD		dwDataLength = 0;	// event data length

    DWORD		dwResult = 1;

   	WORD		length;

	WORD		len;

	WORD		wFlg = 0;			// Event ���H��

	WORD		line  = 0;

	WORD		opnum = 0;

//	WORD		ovnum = 0;

    WORD		wFlag = 0;			// trace ��

    BYTE		byMtp = 0;			// �L�r���s�b Flag

//	BYTE		szTyohyo = 0;		// �b�����L����

//	BYTE		szKanryo = 0;		// ���F�ɰʧ@�i�_����

//	BYTE		byKanryo = 0;		// ���F�ɰʧ@�i�_

	BYTE		byQBDFlag = 0;		// �s�P�L�r�B�z Flag

	BYTE		byQFORMFlag = 0;    // �]�wform flag

	BOOL		bRet = 0;			// �����C�L�����G

//	JIS2BIG5	jisbig;				// ��X CLASS

	BYTE		byDSPEND_Flag = 0;  // DSPEND flag

	LPBYTE		DataPtr, BlockPtr;



//	HKEY		hKey;				// Added by NEC TAIWAN LTD. Y.F.Lin 1998.12.10

	BYTE		Data[16];			//						:

	DWORD       dwRetTCB = 0;		//

//	DWORD		dwSizeTCB;			//	

	unsigned int prn_len_title;				//add by tclmk for �@��L�����C�L

	DWORD		dwActual_ksp;       //KSP file position by tclmk 20020328

	CFile		Kspfile;            //KSP file by tclmk 20020328

	BYTE		Ksprec[8192];		//KSP file

	int			Ksplen;				//KSP file

	int			Kspidx;				//KSP file

	WORD msglen = 0;

	CHAR	msg[8192];


   static CHAR  lpszFuncName[] = "CHostMessage::MyEMessageRecv";

// Entry trace

	COMN_TraceWrite(&wFlag, TRACELEVEL_6,lpszFuncName,0);



	//added by gcl858 for inkan 200709

	//sprintf(Seal_msg,"00;ADD;ACC=010241234567");

	//end by gcl858 for inkan 200709



/////////////////////////   �g�U��q��    ////////////////////////////	

	CFile file;

	LPCTSTR lpszFileName = "E-Message_Down.dat";

/*	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\NEC\\NBT\\CTwHostMessage", 0, KEY_READ, &hKey) == ERROR_SUCCESS)

	{

		ZeroMemory(Data, sizeof(Data));

		dwSizeTCB = 16;

		if (RegQueryValueEx(hKey, "E-Message_Up", NULL, NULL, &Data[0], &dwSizeTCB) == ERROR_SUCCESS)

		{

			if (Data[0] == '1')	// Writing Flag On

			{

				if (file.Open(lpszFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite, NULL))

				{

					DWORD dwActual = file.SeekToEnd();

					file.Write(lpbySentence, SentenceLength);

					Data[0]=0X0D;

					Data[1]=0X0A;

					file.Write(Data, 2);

					file.Close();

				}

			}

		}

		dwRetTCB = RegCloseKey(hKey);

	}

*/

	CFileStatus status;

	char nowtime[24];

	SYSTEMTIME *lpSystemTime=new SYSTEMTIME;

	GetSystemTime(lpSystemTime);

	memset(nowtime,0,sizeof(nowtime));

	sprintf(nowtime,"**%d/%d/%d-%d:%d:%d\t:",lpSystemTime->wYear,lpSystemTime->wMonth,lpSystemTime->wDay,lpSystemTime->wHour,lpSystemTime->wMinute,lpSystemTime->wSecond);



	if (CFile::GetStatus(lpszFileName, status))	// Log File Exists

	{

		if (status.m_size>512*1024)

			CFile::Remove(lpszFileName);



	}

	if (file.Open(lpszFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite, NULL))

	{

		DWORD dwActual = file.SeekToEnd();

		file.Write(nowtime, strlen(nowtime));

		file.Write(lpbySentence, SentenceLength);

		Data[0]=0X0D;

		Data[1]=0X0A;

		file.Write(Data, 2);

		file.Close();

	}





///////////////////////  FILE WRITE END  //////////////////////////////





// Journal Object Pointer���o



	lpCmTradeJournal = CmTradeJournal::GetObjectPointer(CmTradeJournal::READ_WRITE);

	if(NULL == lpCmTradeJournal)

		COMN_EventReportErrINCON(0,0,NULL,

			lpszFuncName,"CmTradeJournal::GetObjectPointer Error");



	if (m_wQPConvert){

		///////////////////////////////////////////////

		//for ITP print control code convertion

		// *************************************

		//	�`�N !! �H�U�T�榸�Ǥ��i�ܧ�

		// *************************************

		//�]��ITP1�L�r�Y�L�k��^�A�G�J������w��ɻݥ��N�L�r�Y����̫e��

		jisbig.checkHorizonCtl(lpbySentence, &SentenceLength); 

		//�]��QP32�������w�챱��X�PITP1���@�ˡA�G���NQP32������X�ഫ��ITP1������X

		jisbig.checkESCsequence(lpbySentence, SentenceLength);

	}

	m_dwResultLength = SentenceLength;



	// �����

    m_form = NULL;

	DBC_FIRST_FLG = 0;	// �ȩw

	m_MtpFormType =0;	// MTP form type added by Pack Hsieh

	m_szTsutyo = 0;// �q�b�U���L����, FLAG OFF

	m_MtpInfo = 0; // MTP�L�r����



	m_lpCmMtpLPH = CmMtpLPH::GetObjectPointer();



	if(NULL != m_lpCmMtpLPH) 

		byMtp = 1;

	

	//  ���F�ɰʧ@�E�C�^������o

	lpCTrWindowsAP = (CTrWindowsAP* )CTrWindows::GetObjectPointer();

	lpCTrWindowsAP -> Clear( "REF_HOST", FALSE );



	// ���\ HardCopy

	lpCcKeyHardCopy = (CcKeyHardCopy* )CcKeyHardCopy::GetObjectPointer();

	lpCcKeyHardCopy -> PermitCopy();



	LoopPage_FLAG = 0;			//KSP loop initial 20020328 by tclmk

	//save length of message

	len = (WORD) SentenceLength; //tclmk

	place = 2;



	//chech that if there is another P-Message

	if (len > 2){

		char	tmp[4];

		ZeroMemory(tmp, 4);

		tmp[0] = 0x1F;

		memcpy(&tmp[1], (char *)lpbySentence, 2);

		if (strstr((char *)lpbySentence, tmp)){ //find another P-Message tclmk

			MyErrorMsg("�U��q��s�観�~�A�Ы��ܢ���", 1);

			MyApJNLWrite("�U��q��s�観�~", 16);

			MyApJNLFlush();

			m_byLoop = 1; // 

			return CHostMessage::Void;

		}

	}

//added by gcl858 20090812 for �{�ҦL�r�K�X���i�gjournal
	char	Jn_Sentence_temp[8192];
//	DWORD	Jn_Sentence_temp_Len;
	char	*lpStartSearch,*lpFind;
	char	str_PWENB[]={0x1A,0xA8,0x20,0x79,0};
	char	str_PWDSB[]={0x1A,0xA8,0x20,0x70,0};

	memset(Jn_Sentence_temp,0,sizeof(Jn_Sentence_temp));
	memcpy(Jn_Sentence_temp,lpbySentence,SentenceLength);
	lpStartSearch=&Jn_Sentence_temp[0];
    

	lpFind=strstr(lpStartSearch,str_PWENB);
	if(lpFind!=NULL)
	{
	memset(Jn_Sentence,0,sizeof(Jn_Sentence));
		memset(lpbySentence,0,5120);
		while(lpFind!=NULL)
		{
			//1.��¸��
			strncat((char *)Jn_Sentence,lpStartSearch,lpFind-lpStartSearch);
			strncat((char *)lpbySentence,lpStartSearch,lpFind-lpStartSearch);

			//2.���zstart
			lpStartSearch=lpFind+strlen(str_PWENB);
			//3.��end
			lpFind=strstr(lpStartSearch,str_PWDSB);
			if(lpFind!=NULL)
			{
				//4.�Ϥ��G�ؤ��P��
				//JOURNAL FILL
				memset(((char *)Jn_Sentence)+strlen((char *)Jn_Sentence),'*',lpFind-lpStartSearch);
				//DATA COPY
				memcpy((char *)(lpbySentence+strlen((char *)lpbySentence)),lpStartSearch,lpFind-lpStartSearch);
				//5.���Xend
				lpStartSearch=lpFind+strlen(str_PWDSB);

				lpFind=strstr(lpStartSearch,str_PWENB);
			}
			else
			{
				//4.�S��END�X
				//JOURNAL FILL
				memcpy((char *)(Jn_Sentence+strlen((char *)Jn_Sentence)),lpStartSearch,strlen(lpStartSearch));
				//DATA COPY
				memcpy((char *)(lpbySentence+strlen((char *)lpbySentence)),lpStartSearch,strlen(lpStartSearch));
				lpStartSearch+=strlen(lpStartSearch);
				break;
			}
		}

		if(strlen(lpStartSearch)>0)//�̫�T�{�B�z
		{
			//JOURNAL FILL
			memcpy((char *)(Jn_Sentence+strlen((char *)Jn_Sentence)),lpStartSearch,strlen(lpStartSearch));
			//DATA COPY
			memcpy((char *)(lpbySentence+strlen((char *)lpbySentence)),lpStartSearch,strlen(lpStartSearch));
				
		}
		SentenceLength=strlen((char *)lpbySentence);
	}
	else//�����K�X�r�u���¦�
	{
		memset(Jn_Sentence,0,sizeof(Jn_Sentence));
	memcpy(Jn_Sentence,lpbySentence,SentenceLength);
	}
//ended by gcl858 20090812 for �{�ҦL�r�K�X���i�gjournal

//******* Start Write Journal	

//	memset(Jn_Sentence,0,sizeof(Jn_Sentence));

//	memcpy(Jn_Sentence,lpbySentence,SentenceLength);

//added by gcl858 20101006 ACBC Don't Wait
	DWORD		dwJNLResult = 1;
//end added by gcl858 20101006 ACBC Don't Wait


	DataPtr = Jn_Sentence + place; //skip the first 2 bytes

	BlockPtr = jisbig.Mystrchr((char *)Jn_Sentence, 0x1f,len); //search the block end



//	nowform = 0;//�{�b�U�b���y���T���O�@�r

	while((place < len) && (BlockPtr)){

//		CHAR	err[0xff];



		CHAR	str_CBCODE[4];

		int		idx;

		LPBYTE	lpbySub;



	    m_dwNowForm = 0;

		int find_qqp =0;  //add for KSP

		int idxp = 0;	  //add for KSP	



		memset(str_CBCODE, 0, 4); //clear the buffer

		length = (WORD)(BlockPtr - DataPtr);//get the block length

		if (length < 3){

//				sprintf(err, "CB_CODE�q�夣��(CBCODE)");

//				COMN_EventReportErrETC(0, len, Sentence, "CHostMessage::EMessageRecv", err);

				MyErrorMsg("�U��q��s�観�~�A�Тܢ���", 1);

				MyApJNLWrite("�U��q��s�観�~", 16);

				MyApJNLFlush();

				m_byLoop = 1; // 

				return CHostMessage::Void;

		}



		memcpy(str_CBCODE, DataPtr, 3);

		for (idx = 0; idx < CBCODE_NUM; idx++){

			if (!memcmp(str_CBCODE, CB_String[idx], 3))

				break;

		}

		place = DataPtr - Jn_Sentence; //find the correct pointer

		place += 3;	//skip the CB code

		switch(idx){//CB1

		case INUM_Xqq: // 55: error "X"

			break;

		case INUM_qqq: // 0: @@@ �L����

			break;



		////////////////////////////////////////////////////

		//		�C��ƥX

		////////////////////////////////////////////////////

		case INUM_qDB: // 18: �C��ƥX, �ǲ��f

		case INUM_qDD: // 19: �C��ƥX, �s�P

		case INUM_qDF: // 20: �C��ƥX, �Ү�

		case INUM_qDG: // 21: �C��ƥX, �s�P�f�@��

			break;



		case INUM_qBA: // 8: �C��L�r, Journal

		case INUM_qBB: // 9: �C��L�r, �ǲ��f

			// MTP�����Q�p

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



			if (INUM_qBA == idx){ //write journal only

				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			}

			else{ //print 

				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			}

			break;



		////////////////////////////////////////////////////

		//		�C��L�r

		////////////////////////////////////////////////////

		case INUM_qBC: // 10: �C��L�r, �ǲ��f+Journal

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



			//�U��q�� JOURNAL

//			if (idx == INUM_qBC){

				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

//			}



			break;



		case INUM_qBF: // 12: �C��L�r, �Ү�

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



			//�U��q�� JOURNAL

//			if (idx == INUM_qBC){

				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

//			}



			break;



		case INUM_qBD: // 11: �C��L�r, �s�P

		case INUM_qBG: // 13: �C��L�r, �s�P�f�@��

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;



		////////////////////////////////////////////////////

		//		�C��L�r��ƥX

		////////////////////////////////////////////////////

		case INUM_qCD: // 15: �C��L�r��ƥX, �s�P

		case INUM_qCG: // 17: �C��L�r��ƥX, �s�P�f�@��

			lpbySub = DataPtr + 3;

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

			    *(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;



		case INUM_qCB: // 14: �C��L�r��ƥX, �ǲ��f

			lpbySub = DataPtr + 3;

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

				*(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;

		case INUM_qCF: // 16: �C��L�r��ƥX, �Ү�

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

		    	*(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;



		////////////////////////////////////////////////////

		//		�C��l�J

		////////////////////////////////////////////////////

		case INUM_qAD: // = 5: @AD �C��l�J, �s�P

		case INUM_qAG: // = 7: @AG �C��l�J, �s�P�f�@��

			break;



		case INUM_qAB: //  4: @AB �C��l�J, �ǲ��f

		case INUM_qAF: // = 6: @AF �C��l�J, �Ү�

			break;

		case INUM_qqH: //  1: @@H MS

			break;



		case INUM_AEK: // 23: �歵, CRT����, Message������

		case INUM_AEM: // 45: �歵, CRT����, Message������+journal

		case INUM_qEK: // 22: CRT����, Message������

		case INUM_qEM: // 26: CRT����, Message������ + journal

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;



		case INUM_AEL: // 25: �歵, CRT����, Monitor������

		case INUM_AEN: // 28: �歵, CRT����, Monitor������ + journal

		case INUM_qEL: // 24: CRT����, Monitor������

		case INUM_qEN: // 27: CRT����, Monitor������ + journal

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			//Added by gcl858 20101006 ACBC Don't Wait
			dwJNLResult = CenterDsp;

			break;



//		case INUM_AEK: // 23: �歵, CRT����, Message������

		case INUM_IEK: // 49: �歵error, CRT����, Message������

		case INUM_MEK: // 51: �歵reset error "M", CRT����, Message������

		case INUM_NEK: // 53: �歵reset error "N", CRT����, Message������

		case INUM_EEK: // 44: �歵reset, CRT����, Message������

//		case INUM_AEM: // 45: �歵, CRT����, Message������+journal

		case INUM_EEM: // 46: �歵reset, CRT����, Message������+journal

		case INUM_FEK: // 47: �s��reset, CRT����, Message������

		case INUM_FEM: // 48: �s��reset, CRT����, Message������+journal

		case INUM_MEM: // 52: �s��reset error "M", CRT����, Message������+journal

		case INUM_IEM: // 50: �s��error, CRT����, Message������+journal

		case INUM_NEM: // 54: �s��reset error "N", CRT����, Message������+journal

//		case INUM_qEM: // 26: CRT����, Message������ + journal

			lpbySub = DataPtr;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			//Added by gcl858 20101006 ACBC Don't Wait
			dwJNLResult = CenterErr;

			break;



		case INUM_qGG: // 34: ���Ʊ���, �s�P�f�@��

			lpbySub = DataPtr + 3;

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

			    *(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			//Added by gcl858 20101006 ACBC Don't Wait
			dwJNLResult = CenterDsp;

			break;



		case INUM_AGL: // 36: �歵, ���Ʊ���, Monitor������

		case INUM_AGN: // 38: �歵, ���Ʊ���, Monitor������ + journal

		case INUM_qGL: // 35: ���Ʊ���, Monitor������

		case INUM_qGN: // 37: ���Ʊ���, Monitor������ + journal

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			//Added by gcl858 20101006 ACBC Don't Wait
			dwJNLResult = CenterDsp;

			break;



		case INUM_qGP: // 40: ���Ʊ���, KSP

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub+1);

			break;

		case INUM_qqP: // = 3: @@P KSP

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub );

			//MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub);

			break;



		case INUM_qGZ: // 39: ���Ʊ���, ���[message

		case INUM_qqZ: // 2: @@Z ���[message

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			break;



		case INUM_XFq: // 56: error ����blinking
			//Added by gcl858 20101006 ACBC Don't Wait
			dwJNLResult = CenterDsp;

			break;



		case INUM_qWW: // 29: overlap����, control

			break;



		case INUM_101: // = 57, 

		case INUM_102: // = 58, 

		case INUM_103: // = 59, 

		case INUM_104: // = 60, 

		case INUM_201: // = 61, 

		case INUM_202: // = 62, 

		case INUM_203: // = 63, 

		case INUM_204: // = 64,

			break;



		case INUM_qW1: // = 30, 

		case INUM_qW2: // = 31, 

		case INUM_qW3: // = 32, 

		case INUM_qW4: // = 33,

			break;



		case INUM_1W1: // = 65, 

		case INUM_1W2: // = 66, 

		case INUM_1W3: // = 67, 

		case INUM_1W4: // = 68, 

		case INUM_2W1: // = 69, 

		case INUM_2W2: // = 70, 

		case INUM_2W3: // = 71, 

		case INUM_2W4: // = 72,

			break;



		case INUM_1C1: // = 73, 

		case INUM_1C2: // = 74, 

		case INUM_1C3: // = 75, 

		case INUM_1C4: // = 76, 

		case INUM_2C1: // = 77, 

		case INUM_2C2: // = 78, 

		case INUM_2C3: // = 79, 

		case INUM_2C4: // = 80,

			break;

		case INUM_qOT: // 41: open, TBC file

			break;

		case INUM_qRT: // 42: write, TBC file

			break;

		case INUM_qST: // 43: close, TBC file

			break;

		case INUM_XXX:

			lpbySub = DataPtr + 3;

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;



//added by gcl858 for inkan 200709

		case INUM_LSq:

			lpbySub = DataPtr;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			memcpy(Seal_msg,lpbySub+3,BlockPtr - lpbySub-3);

			if(Seal_msg[strlen(Seal_msg)-1]==0x1f)

				Seal_msg[strlen(Seal_msg)-1]=0x00;

			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;



//end added by gcl858 for inkan 200709


//added by gcl858 for OffPay 201004
		case INUM_qNO:
			//Added by gcl858 20101006 ACBC Don't Wait
			dwJNLResult = CenterDsp;

			HKEY	hKey1;
			BYTE	Data1[2];      // AC�O�_���W
			BYTE	Data2[2];      // ACBC_DEBUG �O�_����
			DWORD	dwSize1;
			DWORD	dwRet1;
			dwSize1 = sizeof(Data1);
			ZeroMemory(Data1, sizeof(Data1));
			if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\NEC\\NBT\\CmDevice\\DeviceInfo\\AC", 0, KEY_READ, &hKey1) == ERROR_SUCCESS)
			{				
				dwRet1 = RegQueryValueEx(hKey1, "DEVICE_EXISTENCE", NULL, NULL, Data1, &dwSize1);
				dwRet1 = RegCloseKey(hKey1);
			}
			ZeroMemory(Data2, sizeof(Data2));
			if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\NEC\\NBT\\ApTellerOpen", 0, KEY_READ, &hKey1) == ERROR_SUCCESS)
			{				
				dwRet1 = RegQueryValueEx(hKey1, "ACBC_DEBUG", NULL, NULL, Data2, &dwSize1);
				dwRet1 = RegCloseKey(hKey1);
			}

			lpbySub = DataPtr;
			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			if(!((Data1[0]=='1')||(Data2[0]=='1')||(memcmp(lpbySub+3,"3",1) == 0)))   //�LACBC�ɩΥD�޺ݭn�d�߮�
			{
				char cSP;

				memset(OffPay_msg,0,sizeof(OffPay_msg));
				memcpy(&cSP,lpbySub+3,1);
				memcpy(OffPay_msg,lpbySub+4,BlockPtr - lpbySub-4);
				memcpy(&cSP,lpbySub+3,1);

				if(OffPay_msg[strlen(OffPay_msg)-1]==0x1f)
					OffPay_msg[strlen(OffPay_msg)-1]=0x00;
			
				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);
				break;
			}
			else                                                       //�s��ACBC��
			{
				char cSP, cAutoSend;
				char cGamen[9], cItemData[19],tempScreen[9];
				CmTradeJournal* lpCmTradeJournal;	// Journal Object Pointer --
     
				ZeroMemory(tempScreen, sizeof(tempScreen));

				memcpy(&cSP,lpbySub+3,1);                                 // 1 byte   1:�s�� 2:�I��  3:893129

				if(!(memcmp(&cSP,"3",1) == 0))
				{
					memcpy(cGamen,lpbySub+4,8);                           // 8 byte   �e���s��
					memcpy(&cAutoSend,lpbySub+12,1);                      // 1 byte   0:���ǰe 1:�ǰe
					memcpy(cItemData,lpbySub+13,18);                      //18 byte   ���ظ�T
				}

				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);


        		// Journal Object Pointer���o 
				lpCmTradeJournal = CmTradeJournal::GetObjectPointer(CmTradeJournal::READ_WRITE);
				if(FALSE == lpCmTradeJournal->GetItemData(JN_TRAN_NO, tempScreen))
					COMN_EventReportErrINCON(0,0,NULL,lpszFuncName,"CmTradeJournal->GetItemData JN_TRAN_NO Error");

				if( memcmp(&tempScreen[2], "8", 1) == 0 )
				{
					if(memcmp(&cSP,"1",1) == 0)                           //�s��
					{
						if(OPM_SetGamenNo((unsigned char *)cGamen) == TRUE)
							OPM_SetItemData((unsigned char *)cItemData,BlockPtr - lpbySub - 13);
					}
					else if(memcmp(&cSP,"2",1) == 0)                      //�I��
					{
						if(OPM_SetGamenNo((unsigned char *)cGamen) == TRUE)
							OPM_SetItemData((unsigned char *)cItemData,BlockPtr - lpbySub - 13);
					}
					else if(memcmp(&cSP,"3",1) == 0)                      //�d�q��
					{  
						ZeroMemory(msg, sizeof(msg));
						MyCreateStr_FnDepo(msg);
						MyApJNLWrite(msg, strlen(msg));
						break;
			
					}
					if(memcmp(&cAutoSend,"1",1) == 0)                     //�����۰ʫ��U�ǰe��
						OPM_AutoSend();
				}
				break;
			}
//end added by gcl858 for OffPay 201004

		default:

			if (1){

				lpbySub = DataPtr;

				jisbig.comm_Chinese(lpbySub, len - place + 3);

				MyApJNLWrite((char *)lpbySub, len - place + 3);

				MyErrorMsg("�U��q��s�観�~�A�Ы��ܢ���", 1);

				MyApJNLWrite("�U��q��s�観�~", 16);

				MyApJNLFlush();

				m_byLoop = 1; // 

				return CHostMessage::Void;



//				CcCenterTrErr();

//				dwResult = CenterErr;

			}

			//ERROR

	/*		{

				CHAR err[0xff];

				sprintf(err, "�U��q�夣��(�q�����) %x", place - 1);

				COMN_EventReportErrETC(0, len, Sentence, "CHostMessage::EMessageRecv", err);

			}  */

			break;

		}



		place++;

		DataPtr = BlockPtr + 1; //skip the first 2 bytes

		BlockPtr = jisbig.Mystrchr((char *)DataPtr, 0x1f, len-place+1); //search the block end tclmk

	}



	MyApJNLFlush();

//added by gcl858 20101006 ACBC Don't Wait
	if(dwJNLResult == CenterDsp)
		OPM_CenterResult(CenterDsp);
	else if(dwJNLResult == CenterErr)
		OPM_CenterResult(CenterErr);
	else {
		dwJNLResult = Complete;
		OPM_CenterResult(OK);
	}
//end added by gcl858 20101006 ACBC Don't Wait

	len = (WORD) SentenceLength; //tclmk

	place = 2;

//******** End Write Journal 



	DataPtr = lpbySentence + place; //skip the first 2 bytes

	BlockPtr = jisbig.Mystrchr((char *)lpbySentence, 0x1f,len); //search the block end



//	nowform = 0;//�{�b�U�b���y���T���O�@�r

	while((place < len) && (BlockPtr)){

//		CHAR	err[0xff];



		CHAR	str_CBCODE[4];

		int		idx;

		LPBYTE	lpbySub;



	    m_dwNowForm = 0;

		int find_qqp =0;  //add for KSP

		int idxp = 0;	  //add for KSP	



		memset(str_CBCODE, 0, 4); //clear the buffer

		length = (WORD)(BlockPtr - DataPtr);//get the block length

		if (length < 3){

//				sprintf(err, "CB_CODE�q�夣��(CBCODE)");

//				COMN_EventReportErrETC(0, len, Sentence, "CHostMessage::EMessageRecv", err);

				MyErrorMsg("�U��q��s�観�~�A�Тܢ���", 1);

				m_byLoop = 1; // 

				return CHostMessage::Void;

		}



		memcpy(str_CBCODE, DataPtr, 3);

		for (idx = 0; idx < CBCODE_NUM; idx++){

			if (!memcmp(str_CBCODE, CB_String[idx], 3))

				break;

		}

		place = DataPtr - lpbySentence; //find the correct pointer

		place += 3;	//skip the CB code



		switch(idx){//CB1

		case INUM_Xqq: // 55: error "X"

			break;

		case INUM_qqq: // 0: @@@ �L����

			break;



		////////////////////////////////////////////////////

		//		�C��ƥX

		////////////////////////////////////////////////////

		case INUM_qDB: // 18: �C��ƥX, �ǲ��f

		case INUM_qDD: // 19: �C��ƥX, �s�P

		case INUM_qDF: // 20: �C��ƥX, �Ү�

		case INUM_qDG: // 21: �C��ƥX, �s�P�f�@��

//			m_lpCTrInqAnswer->MtpEject(m_form);	//�ƥX

			// MTP�����Q�p

			if(byMtp){

				EndForm();

				WaitLineSet(idx);

			}

			m_szTsutyo = 0;

			break;



		case INUM_qBA: // 8: �C��L�r, Journal

		case INUM_qBB: // 9: �C��L�r, �ǲ��f

			// MTP�����Q�p

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



			if (INUM_qBA == idx){ //write journal only

//				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			}

			else{ //print 

//				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

				if(byMtp){

				//	MyBeginForm(MTP_FORM_MODE, MTP_NEAR_HEAD, MTP_UPPER_INLET);

					MyPrint(); //�L�r�B�z

				}

			}

			break;



		////////////////////////////////////////////////////

		//		�C��L�r

		////////////////////////////////////////////////////

		case INUM_qBC: // 10: �C��L�r, �ǲ��f+Journal

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



			//�U��q�� JOURNAL

//			if (idx == INUM_qBC){

//				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

//			}



			if(byMtp){

			//	MyBeginForm(MTP_FORM_MODE, MTP_NEAR_HEAD, MTP_UPPER_INLET);  

				MyPrint(); //�L�r�B�z

			}



			break;



		case INUM_qBF: // 12: �C��L�r, �Ү�

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



			//�U��q�� JOURNAL

//			if (idx == INUM_qBC){

//				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

//			}



			if(byMtp){

			//	MyBeginForm(MTP_FORM_MODE, MTP_NEAR_HEAD, MTP_LOWER_INLET);  

				MyPrint(); //�L�r�B�z

			}



			break;



		case INUM_qBD: // 11: �C��L�r, �s�P

		case INUM_qBG: // 13: �C��L�r, �s�P�f�@��

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			if(byMtp){

				if (m_szTsutyo || (INUM_qBD == idx)){ //�s�P

					// ���U�l�J���s�P�ݳ]�wform

					if (!byQFORMFlag) {

						if (!strlen((char *)str_CRT2_msg))

							memcpy(str_CRT2_msg, "�s�P", 4); //add by tclmk

				    	MyBeginForm(MTP_PASSBOOK_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);  //�q�b mode

						byQFORMFlag = 1;

					}

					//��]�w�n�D

					//�s�P�ݦۤv����L�r��m

					//���Y�O���e�H�]�w�L�h�����b�]�w��

					if (m_wLine && !byQBDFlag) 

						m_lpCmMtpLPH->LineSet(m_form, ASCIISet(m_wLine), CmMtpLPH::MTP_FAR_HEAD);

					PassbookPrint();//�s�P�L�r�B�z

					byQBDFlag = 1;//�s�P�L�r�B�zflag ON

				}

				else{ //�@��

				//	MyBeginForm(MTP_FORM_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);  //�b�� mode

					MyPrint(); //�@��L�r�B�z

				}

			}



			break;



		////////////////////////////////////////////////////

		//		�C��L�r��ƥX

		////////////////////////////////////////////////////

		case INUM_qCD: // 15: �C��L�r��ƥX, �s�P

		case INUM_qCG: // 17: �C��L�r��ƥX, �s�P�f�@��

			lpbySub = DataPtr + 3;

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

			    *(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			if(byMtp){

				if (m_szTsutyo || (INUM_qCD == idx)){ //�s�P

				//	MyBeginForm(MTP_PASSBOOK_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);  //�q�b mode

					//�� set �n�D

					//�ݦۤv����L�r��m

					if (m_wLine)

						m_lpCmMtpLPH->LineSet(m_form, ASCIISet(m_wLine), CmMtpLPH::MTP_FAR_HEAD);

					PassbookPrint();//�s�P�L�r�B�z

				}

				else{ //�@��

				//	MyBeginForm(MTP_FORM_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);  //�b�� mode

					MyPrint(); //�L�r�B�z

				}

				m_lpCmMtpLPH->EndPrint(m_form); //�L�r�פF�B�z

				WaitLineSet(idx);

				m_szTsutyo = 0;// �q�b�U���L����, FLAG OFF

				m_form = NULL;

				m_MtpFormType = 0;

			}

			else {  //add by tclmk

	//////////////////// add for print �@��L�����L�X��show crt3

				prn_len_title =BlockPtr - lpbySub + 1;

				memcpy(&prnbuffer[prn_len],prn_scrno,8);

				prnbuffer[prn_len+8] = 'M';  // M��itp1 �L�X�榡

				memcpy(&prnbuffer[prn_len+9],&prn_len_title,sizeof(prn_len_title));

				memcpy(&prnbuffer[prn_len+9+sizeof(prn_len_title)],lpbySub,prn_len_title);

				prn_len += prn_len_title+9+sizeof(prn_len_title);

				OutputDisplay(&opnum);

				dwResult = CenterDsp;

			}

			break;



		case INUM_qCB: // 14: �C��L�r��ƥX, �ǲ��f

			lpbySub = DataPtr + 3;

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

				*(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

		//	if(byMtp){

			//	MyBeginForm(MTP_FORM_MODE, MTP_NEAR_HEAD, MTP_UPPER_INLET);  

		//	}

			MyPrint(); //�L�r�B�z

			m_lpCmMtpLPH->EndPrint(m_form); //�L�r�פF�B�z

			WaitLineSet(idx);

			m_szTsutyo = 0;// �q�b�U���L����, FLAG OFF

			m_form = NULL;

			m_MtpFormType = 0;

			break;

		case INUM_qCF: // 16: �C��L�r��ƥX, �Ү�

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

		    	*(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

		//	if(byMtp){

		//		MyBeginForm(MTP_FORM_MODE, MTP_NEAR_HEAD, MTP_LOWER_INLET);  

		//	}

			MyPrint(); //�L�r�B�z

			m_lpCmMtpLPH->EndPrint(m_form); //�L�r�פF�B�z

			WaitLineSet(idx);

			m_szTsutyo = 0;// �q�b�U���L����, FLAG OFF

			m_form = NULL;

			m_MtpFormType = 0;

			break;



		////////////////////////////////////////////////////

		//		�C��l�J

		////////////////////////////////////////////////////

		case INUM_qAD: // = 5: @AD �C��l�J, �s�P

		case INUM_qAG: // = 7: @AG �C��l�J, �s�P�f�@��

			if(byMtp){

				if (idx == INUM_qAG){

					MyBeginForm(MTP_FORM_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);  //�b�� mode

					if (Sentence[place] == '-')

                       PassbookLineSetS(&Sentence[place]);  //�˰h��]�w�A�b���� 

					else

//					   PassbookLineSet(&Sentence[place]); //��]�w�A�b����

					   PassbookLineSet(); //��]�w�A�b����

                }

				else{

					if (!strlen((char *)str_CRT2_msg))

						memcpy(str_CRT2_msg, "�s�P", 4); //add by tclmk

					MyBeginForm(MTP_PASSBOOK_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);//�q�b mode

					byQFORMFlag = 1;

					m_wLine = (Sentence[place] - '0') * 10 + (Sentence[place + 1] - '0');

					PassbookLineSet();

					m_szTsutyo = 1;// �q�b���L����, FLAG ON

				}



			}

			else

				place += 3;



			//clear value

			byQBDFlag = 0; //�s�P�L�r�B�zflag OFF

			break;



		case INUM_qAB: //  4: @AB �C��l�J, �ǲ��f

		case INUM_qAF: // = 6: @AF �C��l�J, �Ү�

			if(byMtp){

				if (idx == INUM_qAB){

					MyBeginForm(MTP_FORM_MODE, MTP_NEAR_HEAD, MTP_UPPER_INLET);

				//	MyBeginForm(MTP_FORM_MODE, MTP_FAR_HEAD);

				// 	PassbookLineSet(-1);

				}

				else{

					MyBeginForm(MTP_FORM_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);

				}

				if (Sentence[place] == '-')

                    PassbookLineSetS(&Sentence[place]);  //�˰h��]�w�A�b���� 

				else

//				    PassbookLineSet(&Sentence[place]); //��]�w�A�b����

				    PassbookLineSet(); //��]�w�A�b����

			}

			else

				place += 3;



			break;

		case INUM_qqH: //  1: @@H MS

			WriteMS();

			EndForm(); //�T�O��s���ϱ����g�J�O���T��

			WaitWriteMS(idx);

			m_szTsutyo = 0;// �q�b�U���L����, FLAG OFF

			break;



		case INUM_AEK: // 23: �歵, CRT����, Message������

		case INUM_AEM: // 45: �歵, CRT����, Message������+journal

			//�歵

			MessageBeep(0xFFFFFFFF);

		case INUM_qEK: // 22: CRT����, Message������

		case INUM_qEM: // 26: CRT����, Message������ + journal

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			char msgDat[200];

			memset(msgDat,0,sizeof(msgDat));

			memcpy(msgDat,lpbySub,BlockPtr - lpbySub + 1);

			CM_DisplayOpMsg( "TCB0001", msgDat, NULL);

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			break;



		case INUM_AEL: // 25: �歵, CRT����, Monitor������

		case INUM_AEN: // 28: �歵, CRT����, Monitor������ + journal

			//�歵

			MessageBeep(0xFFFFFFFF);

		case INUM_qEL: // 24: CRT����, Monitor������

		case INUM_qEN: // 27: CRT����, Monitor������ + journal



			lpbySub = DataPtr + 3;



			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

//			jisbig.dummyESCsequence(lpbySub, BlockPtr - lpbySub + 1);

//			if ((idx == INUM_qEN) || (idx == INUM_AEN))

//				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);



			OutputDisplay(&opnum);

			dwResult = CenterDsp;

			//////////////////// add for print �@��L����

			prn_len_title =BlockPtr - lpbySub + 1;

			memcpy(&prnbuffer[prn_len],prn_scrno,8);

			prnbuffer[prn_len+8] = 0x20;

			memcpy(&prnbuffer[prn_len+9],&prn_len_title,sizeof(prn_len_title));

			memcpy(&prnbuffer[prn_len+9+sizeof(prn_len_title)],lpbySub,prn_len_title);

			prn_len += prn_len_title+9+sizeof(prn_len_title);

			

			break;



//		case INUM_AEK: // 23: �歵, CRT����, Message������

		case INUM_IEK: // 49: �歵error, CRT����, Message������

		case INUM_MEK: // 51: �歵reset error "M", CRT����, Message������

		case INUM_NEK: // 53: �歵reset error "N", CRT����, Message������

		case INUM_EEK: // 44: �歵reset, CRT����, Message������

//		case INUM_AEM: // 45: �歵, CRT����, Message������+journal

		case INUM_EEM: // 46: �歵reset, CRT����, Message������+journal

			//�歵reset error

			MessageBeep(0xFFFFFFFF);



		case INUM_FEK: // 47: �s��reset, CRT����, Message������

		case INUM_FEM: // 48: �s��reset, CRT����, Message������+journal

		case INUM_MEM: // 52: �s��reset error "M", CRT����, Message������+journal

		case INUM_IEM: // 50: �s��error, CRT����, Message������+journal

		case INUM_NEM: // 54: �s��reset error "N", CRT����, Message������+journal

			//�s��reset error

			MessageBeep(0xFFFFFFFF);



//		case INUM_qEM: // 26: CRT����, Message������ + journal



			lpbySub = DataPtr;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



//			if ((idx == INUM_AEM) || (idx == INUM_EEM) ||

//				(idx == INUM_FEM) || (idx == INUM_MEM) ||

//				(idx == INUM_IEM) || (idx == INUM_NEM)){//write �U��q�� JOURNAL

//				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

//			}

			CcCenterTrErr();

			dwResult = CenterErr;

			//////////////////// add for print �@��L����

			prn_len_title =BlockPtr - lpbySub + 1;

			memcpy(&prnbuffer[prn_len],prn_scrno,8);

			prnbuffer[prn_len+8] = 0x20;

			memcpy(&prnbuffer[prn_len+9],&prn_len_title,sizeof(prn_len_title));

			memcpy(&prnbuffer[prn_len+9+sizeof(prn_len_title)],lpbySub,prn_len_title);

			prn_len += prn_len_title+9+sizeof(prn_len_title);

						

			break;



		case INUM_qGG: // 34: ���Ʊ���, �s�P�f�@��

			lpbySub = DataPtr + 3;

			if ( *(BlockPtr-1) == 0x0a) //�̫�@�椣����

			    *(BlockPtr-1) = 0x0d ;  //�ഫ0A1F��0D1F

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

		//	if(byMtp){

		//		MyBeginForm(MTP_FORM_MODE, MTP_NEAR_HEAD, MTP_LOWER_INLET);  

		//	}

			if(byMtp){

				MyPrint(); //�L�r�B�z

				m_lpCmMtpLPH->EndPrint(m_form); //�L�r�פF�B�z

			}

			else {

				//////////////////// add for print �@��L����

				prn_len_title =BlockPtr - lpbySub + 1;

				memcpy(&prnbuffer[prn_len],prn_scrno,8);

				prnbuffer[prn_len+8] = 0x20;

				memcpy(&prnbuffer[prn_len+9],&prn_len_title,sizeof(prn_len_title));

				memcpy(&prnbuffer[prn_len+9+sizeof(prn_len_title)],lpbySub,prn_len_title);

				prn_len += prn_len_title+9+sizeof(prn_len_title);

				place += BlockPtr - lpbySub;

				place ++; //skip 0x1f

			}



			m_PrevNextPage = 1;

			// �����\����i�ϥγ]�w�G

			//�e/����

			lpCTrWindowsAP->ClearFuncProperty("TORIHIKI", 20025, 22, 0x02);

			lpCTrWindowsAP->ClearFuncProperty("TORIHIKI", 20026, 22, 0x02);



			MyOutputDisplay(&opnum);

			dwResult = CenterDsp;



			//***********************

			//�ȩw

//			lpbySub = DataPtr + 3;

//			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

//			CRT2_Output();

//			if(byMtp){

//				m_wLine = 1;

//				//**********//

//			    CHAR lpvBarData[100];

//			    m_lpCmMtpLPH->TurnPage(m_form, '01', '01', 100, lpvBarData);

//			}

			break;



		case INUM_AGL: // 36: �歵, ���Ʊ���, Monitor������

		case INUM_AGN: // 38: �歵, ���Ʊ���, Monitor������ + journal

			//�歵 

			MessageBeep(0xFFFFFFFF);



		case INUM_qGL: // 35: ���Ʊ���, Monitor������

		case INUM_qGN: // 37: ���Ʊ���, Monitor������ + journal



			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);



			OutputDisplay(&opnum);

			dwResult = CenterDsp;



//			if ((idx == INUM_AGN) || (idx == INUM_qGN))

//				MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);



			if(!byMtp){

			//////////////////// add for print �@��L����

				prn_len_title =BlockPtr - lpbySub + 1;

				memcpy(&prnbuffer[prn_len],prn_scrno,8);

				prnbuffer[prn_len+8] = 0x20;

				memcpy(&prnbuffer[prn_len+9],&prn_len_title,sizeof(prn_len_title));

				memcpy(&prnbuffer[prn_len+9+sizeof(prn_len_title)],lpbySub,prn_len_title);

				prn_len += prn_len_title+9+sizeof(prn_len_title);

			}



			m_PrevNextPage = 1;

			// �����\����i�ϥγ]�w�G

			//�e/����

			lpCTrWindowsAP->ClearFuncProperty("TORIHIKI", 20025, 22, 0x02);

			lpCTrWindowsAP->ClearFuncProperty("TORIHIKI", 20026, 22, 0x02);

			break;



		case INUM_qGP: // 40: ���Ʊ���, KSP

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub+1);

			for (idxp = 0; idxp < (BlockPtr - lpbySub-3); idxp++){

				if (!memcmp("@@P", lpbySub+idxp, 3)) {

					find_qqp =1;

					break;

				}

			}

			if (!find_qqp )

				idxp = BlockPtr - lpbySub + 1;

//			MyApJNLWrite((char *)lpbySub, idxp);

			///// ADD PRINTING

			if (sToHost[9] == '2')

				Kspfile.Open(KSPFILENAME, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite , NULL);

			else

				Kspfile.Open(KSPFILENAME, CFile::modeCreate | CFile::modeReadWrite , NULL);

			dwActual_ksp = Kspfile.SeekToEnd();

			ZeroMemory(Ksprec,sizeof(Ksprec));

			Ksplen = 0;

			for(Kspidx=0;Kspidx < idxp;Kspidx++) {

				if (*(lpbySub+ Kspidx) == 0x0A) {

					Ksprec[Ksplen] = 0x0D;

					Ksplen ++;

				}

				Ksprec[Ksplen] = *(lpbySub+ Kspidx);

				Ksplen ++;

			}

			Ksprec[Ksplen] = 0x0D;

			Ksplen ++;

			Ksprec[Ksplen] = 0x0A;

			Ksplen ++;

			Kspfile.Write(Ksprec, Ksplen);

			Kspfile.Close();



			place += idxp ;

			if (*(lpbySub + idxp + 1) == 0x1f)

				place ++; //skip 0x1f

			place--;						//because no 0x1f

			BlockPtr = lpbySub + idxp -1;	//add by tclmk 20020328

			m_PrevNextPage = 2; //KSP LOOP �q��

			break;

		case INUM_qqP: // = 3: @@P KSP

			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub );

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub);

			///// ADD PRINTING

			Kspfile.Open(KSPFILENAME, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite, NULL);

			dwActual_ksp = Kspfile.SeekToEnd();

			ZeroMemory(Ksprec,sizeof(Ksprec));

			Ksplen = 0;

			for(Kspidx=0;Kspidx < (BlockPtr - lpbySub);Kspidx++) {

				if (*(lpbySub+ Kspidx) == 0x0A) {

					Ksprec[Ksplen] = 0x0D;

					Ksplen ++;

				}

				Ksprec[Ksplen] = *(lpbySub+ Kspidx);

				Ksplen ++;

			}

			Ksprec[Ksplen] = 0x0D;

			Ksplen ++;

			Ksprec[Ksplen] = 0x0A;

			Ksplen ++;

			Kspfile.Write(Ksprec, Ksplen);

			Kspfile.Close();



			m_PrevNextPage = 0; //KSP LOOP STOP 

			if ((BlockPtr - lpbySub) > 0) { //display message

				OutputDisplay(&opnum);

				dwResult = CenterDsp;

			}

			place += BlockPtr - lpbySub;

			place ++; //skip 0x1f

			jisbig.CreateProc(KSPCOMMAND);

			break;



		case INUM_qGZ: // 39: ���Ʊ���, ���[message

			m_PrevNextPage = 1;

			// �����\����i�ϥγ]�w�G

			//�e/����

			lpCTrWindowsAP->ClearFuncProperty("TORIHIKI", 20025, 22, 0x02);

			lpCTrWindowsAP->ClearFuncProperty("TORIHIKI", 20026, 22, 0x02);

		case INUM_qqZ: // 2: @@Z ���[message

			//�L������ message, set flag value

			if (*(BlockPtr + 1) == '@'){

				//CB2: medium will be used, then flag on

				if ((*(BlockPtr + 2) >= 'A') && (*(BlockPtr + 2) <= 'D'))

					m_Print_msg = 1; 

				else

					m_Print_msg = 0;

			}



			lpbySub = DataPtr + 3;

			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);

			CRT2_Output();

			break;



		case INUM_XFq: // 56: error ����blinking

			MessageBeep(MB_ICONQUESTION);

			ErrItemEmphasize();

			dwResult = CenterDsp;

			break;



		case INUM_qWW: // 29: overlap����, control

			break;



		case INUM_101: // = 57, 

		case INUM_102: // = 58, 

		case INUM_103: // = 59, 

		case INUM_104: // = 60, 

		case INUM_201: // = 61, 

		case INUM_202: // = 62, 

		case INUM_203: // = 63, 

		case INUM_204: // = 64,

			break;



		case INUM_qW1: // = 30, 

		case INUM_qW2: // = 31, 

		case INUM_qW3: // = 32, 

		case INUM_qW4: // = 33,

			break;



		case INUM_1W1: // = 65, 

		case INUM_1W2: // = 66, 

		case INUM_1W3: // = 67, 

		case INUM_1W4: // = 68, 

		case INUM_2W1: // = 69, 

		case INUM_2W2: // = 70, 

		case INUM_2W3: // = 71, 

		case INUM_2W4: // = 72,

			break;



		case INUM_1C1: // = 73, 

		case INUM_1C2: // = 74, 

		case INUM_1C3: // = 75, 

		case INUM_1C4: // = 76, 

		case INUM_2C1: // = 77, 

		case INUM_2C2: // = 78, 

		case INUM_2C3: // = 79, 

		case INUM_2C4: // = 80,

			break;

		case INUM_qOT: // 41: open, TBC file

			break;

		case INUM_qRT: // 42: write, TBC file

			break;

		case INUM_qST: // 43: close, TBC file

			break;

		case INUM_XXX:

			lpbySub = DataPtr + 3;

//			MyApJNLWrite((char *)lpbySub, BlockPtr - lpbySub + 1);

			CRT2_Output();

			break;

		case INUM_LSq:

			break;

	    case INUM_qNO:
			lpbySub = DataPtr;
			jisbig.comm_Chinese(lpbySub, BlockPtr - lpbySub + 1);
			if(memcmp(lpbySub+3,"3",1) == 0)
			{
				
/*			
			//print out
			m_Print_msg = 1;
			memset(str_CRT2_msg, 0, 120);
			memcpy(str_CRT2_msg, "�{���B�z�����w�s�{���ί�", 24);
			MyBeginForm(MTP_FORM_MODE, MTP_FAR_HEAD, MTP_LOWER_INLET);  //�b�� mode
			m_lpCmMtpLPH->LineSet(m_form, ASCIISet(2), CmMtpLPH::MTP_NEAR_HEAD);
			byQBDFlag = 0; //�s�P�L�r�B�zflag OFF

			m_lpCmMtpLPH->Print(m_form, strlen(msg), msg, MTP_FLUSH);
			m_lpCmMtpLPH->EndPrint(m_form); //�L�r�פF�B�z
			WaitLineSet(17);

			m_szTsutyo = 0;// �q�b�U���L����, FLAG OFF

			m_form = NULL;

			m_MtpFormType = 0;
*/

			//display
				MyOutputDisplay_FnDepo(msg);
				dwResult = CenterDsp;
				break;
			}
			else
				break;

		default:

			if (1){

				lpbySub = DataPtr;

				jisbig.comm_Chinese(lpbySub, len - place + 3);

				MyErrorMsg("�U��q��s�観�~�A�Ы��ܢ���", 1);

				m_byLoop = 1; // 

				return CHostMessage::Void;


			}
			break;
		}

		place++;

		DataPtr = BlockPtr + 1; //skip the first 2 bytes

		BlockPtr = jisbig.Mystrchr((char *)DataPtr, 0x1f, len-place+1); //search the block end tclmk
	}



//	if(byMtp && CenterErr != dwResult) // MTP��?? && Ƿ��ǻǤ��??�H�~

	//modified by Pack Hsieh

	if(byMtp && m_MtpInfo && CenterErr != dwResult) // MTP���� && MTP �L�r && CENTER ERROR �H�~

		bRet = m_lpCmMtpLPH->EndAllPrint();

	
//marked by gcl858 20101006 ACBC Don't Wait
/*	// �ȩw

	if(dwResult == CenterDsp)

		// 

		OPM_CenterResult(CenterDsp);

	else if(dwResult == CenterErr)

		// 

		OPM_CenterResult(CenterErr);

	else {

		dwResult = Complete;



		OPM_CenterResult(OK);

	}
//end marked by gcl858 20101006 ACBC Don't Wait
*/


	if(TRUE == bRet) {



		while(!wFlg) {



			// Event ���H

			if(m_lpCTrInqAnswer->GetMultiEvent(m_multievent,

                                        m_NoOfEvent,

                                        &dwGetEventId,

                                        &dwGetEventKey,

                                        Sentence,

                                        sizeof(Sentence),

                                        &dwDataLength

                                        ) != CNbtThread::OK)

    			COMN_EventReportErrINCON(0,0,NULL, lpszFuncName,"GetMultiEvent Error");



	switch(dwGetEventId){

			case CmMtpLPH::ALARM:

			case CmMtpLPH::ALLDEREGISTERFORM:

				wFlg++;

				break;



			//////////////////////////////////////////

			//added by Pack Hsieh

			case END_ERR_OK: //center error�ݢ�

			case END_ERR_NG: //center error�ܢ�

			case DSPEND:// �ӷ|�e���פF

				if (dwGetEventId == DSPEND){

					// �����\�����ݩ� structure

					WINXFUNCATT	*winxFunAtt = new WINXFUNCATT;

					winxFunAtt->byPushFlag = 0;

					winxFunAtt->byEnable = 0;

					byDSPEND_Flag = 1;

					lpCTrWindowsAP->SetFuncProperty("TORIHIKI", 11003, 0, 0x02, winxFunAtt);

				}



				m_byMessage = 0;

				m_byLoop = 1; //don't wait event

				break;

			//////////////////////////////////////////



			case KEYIN: // key ��U



				if(MID_KEY_VOID == dwGetEventKey) {

					// �X�O�L�Ĩ��H�פF

					dwResult = Void;

					wFlg++;

					break;

				}else {

					// default �B�z�_

				}

    		default:

				if(0 == OPM_EventCallback(dwGetEventId, dwGetEventKey, dwDataLength, Sentence))

					dwResult = End;

	            break;

			}



    	}

	}



	// HardCopy �T�� -- Marked by TCLMK 2000.03.02

//	lpCcKeyHardCopy -> RefuseCopy();



	if (byDSPEND_Flag)

		lpCTrWindowsAP->ClearFuncProperty("TORIHIKI", 11003, 0, 0x02);



    // Exit trace

	COMN_TraceWrite(&wFlag, TRACELEVEL_6,lpszFuncName,0);



	return dwResult;

}
