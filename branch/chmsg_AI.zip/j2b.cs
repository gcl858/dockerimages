using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace JIS2BIG5Converter
{
    public class JIS2BIG5
    {
        private const int MAXWORDNUM = 65536; // Assuming this value based on context
        private byte[] str_CHead = new byte[] { 0x1A, 0x70, 0 };
        private byte[] str_CTail = new byte[] { 0x1A, 0x71, 0 };
        private static ushort[] bigtbl = new ushort[MAXWORDNUM];
        private static ushort[] jistbl = new ushort[MAXWORDNUM];
        private IntPtr neccode_tab_buffer;

        public JIS2BIG5()
        {
            neccode_tab_buffer = IntPtr.Zero;

            FileStream fbig = null;
            FileStream fjis = null;
            
            try
            {
                fbig = new FileStream("jistobig5.tbl", FileMode.Open, FileAccess.Read);
                fjis = new FileStream("big5tojis.tbl", FileMode.Open, FileAccess.Read);
            }
            catch
            {
                if (fbig == null && fjis == null)
                {
                    MessageBox.Show("Can't find JIS <---> BIG5 table!");
                    Environment.Exit(0);
                }
            }

            if (fbig != null)
            {
                Array.Clear(bigtbl, 0, bigtbl.Length);
                BinaryReader reader = new BinaryReader(fbig);
                byte[] buffer = reader.ReadBytes(MAXWORDNUM * sizeof(ushort));
                Buffer.BlockCopy(buffer, 0, bigtbl, 0, buffer.Length);
                fbig.Close();
            }

            if (fjis != null)
            {
                Array.Clear(jistbl, 0, jistbl.Length);
                BinaryReader reader = new BinaryReader(fjis);
                byte[] buffer = reader.ReadBytes(MAXWORDNUM * sizeof(ushort));
                Buffer.BlockCopy(buffer, 0, jistbl, 0, buffer.Length);
                fjis.Close();
            }
        }

        ~JIS2BIG5()
        {
            if (neccode_tab_buffer != IntPtr.Zero)
                Marshal.FreeHGlobal(neccode_tab_buffer);
        }

        // Check ESC sequence for horizontal positioning control codes
        public void CheckESCsequence(byte[] buffer, int length)
        {
            for (int idx = 0; idx <= length; idx++)
            {
                if (buffer[idx] == 0x1b)
                {
                    switch (buffer[idx + 1])
                    {
                        case 0x50: // P
                            if (buffer[idx + 2] >= 0x44 && buffer[idx + 2] <= 0x5F)
                                buffer[idx + 2] = (byte)(buffer[idx + 2] - 4);
                            break;

                        case 0x51: // Q
                        case 0x52: // R
                            if (buffer[idx + 2] >= 0x44 && buffer[idx + 2] <= 0x5F)
                            {
                                buffer[idx + 2] = (byte)(buffer[idx + 2] - 4);
                            }
                            else if (buffer[idx + 2] <= 0x43)
                            {
                                buffer[idx + 1] = (byte)(buffer[idx + 1] - 1);
                                buffer[idx + 2] = (byte)(0x5C + (0x43 - buffer[idx + 2]));
                            }
                            break;

                        case 0x53: // S
                        case 0x54: // T
                        case 0x55: // U
                            if (buffer[idx + 2] >= 0x40 && buffer[idx + 2] <= 0x5F)
                                buffer[idx + 1] = (byte)(buffer[idx + 1] - 3);
                            break;
                    }
                }
            }
        }

        // Check horizontal control for ITP1 print head
        public void CheckHorizonCtl(byte[] buffer, ref uint length)
        {
            int len, idx;
            byte[] newbuffer = new byte[5120];

            if (length > newbuffer.Length)
                return;

            Array.Clear(newbuffer, 0, newbuffer.Length);

            idx = len = 0;
            int ptr = 0;

            while (idx < (int)length)
            {
                if ((buffer[ptr] == 0x1b) &&
                    ((buffer[ptr + 1] >= 0x50) && (buffer[ptr + 1] <= 0x55)))
                {
                    newbuffer[len++] = 0x0D; // line feed, move print head to front
                    newbuffer[len++] = buffer[ptr];
                    ptr++;
                }
                else
                {
                    newbuffer[len++] = buffer[ptr];
                    ptr++;
                    idx++;
                }
            }

            Buffer.BlockCopy(newbuffer, 0, buffer, 0, len);
            // Change the length
            length = (uint)len;
        }

        // Dummy out ITP1 control codes when showing on screen
        public int DummyESCsequence(byte[] buffer, int length)
        {
            int idx, len;
            byte[] newbuffer = new byte[5120];
            
            Array.Clear(newbuffer, 0, newbuffer.Length);
            int ptr2 = 0;
            len = 0;
            int ptr = 0;

            for (idx = 0; idx <= length; idx++)
            {
                if (buffer[ptr] == 0x1b)
                {
                    switch (buffer[ptr + 1])
                    {
                        case 0x31: // 1
                        case 0x32: // 2
                        case 0x33: // 3
                        case 0x34: // 4
                        case 0x28: // (
                        case 0x29: // )
                            idx++;
                            ptr += 2;
                            break;
                        case 0x23: // # 8,9
                            if ((buffer[ptr + 2] >= 0x38) && (buffer[ptr + 2] <= 0x39))
                            {
                                idx += 2;
                                ptr += 3;
                            }
                            break;
                        case 0x5f: // - Q,R,T,U
                            if ((buffer[ptr + 2] >= 0x51) && (buffer[ptr + 2] <= 0x55) && (buffer[ptr + 2] != 0x53))
                            {
                                idx += 2;
                                ptr += 3;
                            }
                            break;
                        case 0x58: // x A ~ _
                            if ((buffer[ptr + 2] >= 0x41) && (buffer[ptr + 2] <= 0x5f))
                            {
                                idx += 2;
                                ptr += 3;
                            }
                            break;
                        case 0x59: // Y @ ~ _
                            if ((buffer[ptr + 2] >= 0x40) && (buffer[ptr + 2] <= 0x5F))
                            {
                                idx += 2;
                                ptr += 3;
                            }
                            break;
                        case 0x50: // P @ ~ _
                        case 0x51: // Q @ ~ _
                        case 0x52: // R @ ~ _
                            if (buffer[ptr + 2] >= 0x40 && buffer[ptr + 2] <= 0x5F)
                            {
                                idx += 2;
                                ptr += 3;
                            }
                            break;
                        case 0x53: // S @ ~ M
                            if (buffer[ptr + 2] >= 0x40 && buffer[ptr + 2] <= 0x4d)
                            {
                                idx += 2;
                                ptr += 3;
                            }
                            break;
                        case 0x63: // 63H 8
                            if (buffer[ptr + 2] == 0x38)
                            {
                                idx += 2;
                                ptr += 3;
                            }
                            break;
                        default:
                            ptr++;
                            break;
                    }
                }
                else
                {
                    newbuffer[ptr2++] = buffer[ptr++];
                    if (newbuffer[ptr2 - 1] == 0)
                        newbuffer[ptr2 - 1] = 0x20;
                    len++;
                }
            }
            
            Array.Clear(buffer, 0, length);
            Buffer.BlockCopy(newbuffer, 0, buffer, 0, length);
            return len;
        }

        // Convert JIS character to BIG5
        public bool Char_Jis2Big5(byte[] ptr, byte jis_ch1, byte jis_ch2)
        {
            byte ch1, ch2;
            int c1, c2, num;
            byte[] Jisptr = new byte[3];

            Jisptr[0] = jis_ch1;
            Jisptr[1] = jis_ch2;
            Jisptr[2] = 0;
            
            if (!Jis_area(Jisptr))
            {
                ptr[0] = jis_ch1;
                ptr[1] = jis_ch2;
                return false;
            }
            
            ch1 = jis_ch1;
            ch2 = jis_ch2;
            
            if ((ch1 & 0x80) != 0)
            {
                if (ch2 <= 0x7E)
                {
                    // G2 convert
                    c1 = ch1 - 0xa1;
                    c2 = ch2 - 0x21;
                    num = (c1 * 94 + c2 + 3 * 8836);
                }
                else
                {
                    // G1 convert
                    c1 = ch1 - 0xa1;
                    c2 = ch2 - 0xa1;
                    num = (c1 * 94 + c2 + 8836);
                }
            }
            else if ((ch1 >= 0x21) && (ch2 >= 0x21))
            {
                if (ch2 <= 0x7E)
                {
                    // G0 convert
                    c1 = ch1 - 0x21;
                    c2 = ch2 - 0x21;
                    num = (c1 * 94 + c2);
                }
                else
                {
                    // G3 convert
                    c1 = ch1 - 0x21;
                    c2 = ch2 - 0xa1;
                    num = (c1 * 94 + c2 + 8836 + 8836);
                }
            }
            else
            {
                ptr[1] = 0xCF;
                ptr[0] = 0xA1;
                return false;
            }

            ptr[1] = (byte)(bigtbl[num] >> 8);
            // Ensure we don't fill in NULL, convert to +
            if (ptr[1] == 0)
                ptr[1] = 0xCF;
                
            ptr[0] = (byte)(bigtbl[num]);
            // Ensure we don't fill in NULL
            if (ptr[0] == 0)
                ptr[0] = 0xA1;
                
            return true;
        }

        // Convert JIS string to BIG5
        public bool Str_Jis2Big5(byte[] JTOB, int length)
        {
            byte jis_ch1;
            byte jis_ch2;
            byte[] jis_code = new byte[2];
            byte[] ptr1 = new byte[length];

            Array.Clear(ptr1, 0, length);
            int ptr = 0;

            for (int idx = 0; idx < length; idx += 2)
            {
                if (idx + 1 < length)
                {
                    Buffer.BlockCopy(JTOB, idx, jis_code, 0, 2);

                    // For Ki 0x20 0x20 ... ko bug
                    if ((jis_code[0] == 0x20) && (jis_code[1] == 0x20))
                    {
                        jis_code[0] = 0x21;
                        jis_code[1] = 0x21;
                    }
                    
                    jis_ch1 = jis_code[0];
                    jis_ch2 = jis_code[1];

                    // Check control code first
                    if (jis_ch1 == 0x1b) // ESC sequence
                    {
                        switch (jis_ch2)
                        {
                            case 0x31:
                            case 0x32:
                            case 0x33: // Red text
                            case 0x34: // Black text
                            case 0x45: // 12 chars/inch
                            case 0x28: // Direction print designation
                            case 0x29: // One-way print designation
                            case 0x4b: // Kanji horizontal print mode
                            case 0x74: // Kanji print mode
                            case 0x71: // Half-character text setting
                                ptr1[ptr++] = jis_code[0];
                                ptr1[ptr++] = jis_code[1];
                                break;

                            case 0x50:
                            case 0x51:
                            case 0x52: // Horizontal
                                if ((idx + 2 < length) && (JTOB[idx + 2] >= 0x40) && (JTOB[idx + 2] <= 0x5f))
                                {
                                    // It's the difference between QP32 & ITP
                                    if (JTOB[idx + 2] >= 0x44)
                                        JTOB[idx + 2] = (byte)(JTOB[idx + 2] - 4);

                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 3);
                                    ptr += 3;
                                    idx++; // Will be increased again later
                                }
                                else
                                {
                                    byte[] tempPtr = new byte[2];
                                    Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                                    ptr1[ptr++] = tempPtr[0];
                                    ptr1[ptr++] = tempPtr[1];
                                }
                                break;

                            case 0x53:
                                if ((idx + 2 < length) && (JTOB[idx + 2] >= 0x40) && (JTOB[idx + 2] <= 0x4e))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 3);
                                    ptr += 3;
                                    idx++; // Will be increased again later
                                }
                                else
                                {
                                    byte[] tempPtr = new byte[2];
                                    Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                                    ptr1[ptr++] = tempPtr[0];
                                    ptr1[ptr++] = tempPtr[1];
                                }
                                break;

                            case 0x58:
                                if ((idx + 2 < length) && (JTOB[idx + 2] >= 0x41) && (JTOB[idx + 2] <= 0x5f))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 3);
                                    ptr += 3;
                                    idx++; // Will be increased again later
                                }
                                else
                                {
                                    byte[] tempPtr = new byte[2];
                                    Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                                    ptr1[ptr++] = tempPtr[0];
                                    ptr1[ptr++] = tempPtr[1];
                                }
                                break;

                            case 0x59:
                                if ((idx + 2 < length) && (JTOB[idx + 2] >= 0x40) && (JTOB[idx + 2] <= 0x5f))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 3);
                                    ptr += 3;
                                    idx++; // Will be increased again later
                                }
                                else
                                {
                                    byte[] tempPtr = new byte[2];
                                    Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                                    ptr1[ptr++] = tempPtr[0];
                                    ptr1[ptr++] = tempPtr[1];
                                }
                                break;

                            case 0x5f:
                                if (idx + 2 < length)
                                {
                                    switch (JTOB[idx + 2])
                                    {
                                        case 0x51: // Line feed 1/12
                                        case 0x52: // Line feed 1/10
                                        case 0x54: // Line feed 1/6
                                        case 0x55: // Line feed 1/5
                                            Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 3);
                                            ptr += 3;
                                            idx++; // Will be increased again later
                                            break;
                                        default:
                                            byte[] tempPtr = new byte[2];
                                            Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                                            ptr1[ptr++] = tempPtr[0];
                                            ptr1[ptr++] = tempPtr[1];
                                            break;
                                    }
                                }
                                else
                                {
                                    byte[] tempPtr = new byte[2];
                                    Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                                    ptr1[ptr++] = tempPtr[0];
                                    ptr1[ptr++] = tempPtr[1];
                                }
                                break;

                            case 0x63:
                                if ((idx + 2 < length) && (JTOB[idx + 2] == 0x38))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 3);
                                    ptr += 3;
                                    idx++; // Will be increased again later
                                }
                                else
                                {
                                    byte[] tempPtr = new byte[2];
                                    Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                                    ptr1[ptr++] = tempPtr[0];
                                    ptr1[ptr++] = tempPtr[1];
                                }
                                break;

                            default:
                                byte[] tempPtr2 = new byte[2];
                                Char_Jis2Big5(tempPtr2, jis_ch1, jis_ch2);
                                ptr1[ptr++] = tempPtr2[0];
                                ptr1[ptr++] = tempPtr2[1];
                                break;
                        }
                    }
                    else if (jis_ch1 == 0x1A)
                    {
                        if ((jis_ch2 == 0x24) && (idx <= length - 5))
                        {
                            if (((JTOB[idx + 2] == 0x21) &&
                                (JTOB[idx + 3] == 0x20) &&
                                (JTOB[idx + 4] == 0x78)) ||
                                ((JTOB[idx + 2] == 0x21) &&
                                (JTOB[idx + 3] == 0x24) &&
                                (JTOB[idx + 4] == 0x74)))
                            {
                                Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 5);
                                idx += 3; // Cause idx will be increase 2 later
                                ptr += 5;
                            }
                        }
                        else if ((jis_ch2 == 0x26) && (idx <= length - 8))
                        {
                            if ((JTOB[idx + 2] == 0x21) &&
                                (JTOB[idx + 3] == 0x20) &&
                                (JTOB[idx + 4] == 0x68))
                            {
                                if ((JTOB[idx + 5] == 0x21) &&
                                    (JTOB[idx + 6] == 0x20) &&
                                    (JTOB[idx + 7] == 0x78))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 8);
                                    ptr += 8;
                                    idx += 6; // Cause idx will be increase 2 later
                                }
                                else if ((JTOB[idx + 5] == 0x22) &&
                                        (JTOB[idx + 6] == 0x21) &&
                                        (JTOB[idx + 7] == 0x76))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 8);
                                    ptr += 8;
                                    idx += 6; // Cause idx will be increase 2 later
                                }
                            }
                            else if ((JTOB[idx + 2] == 0x22) &&
                                    (JTOB[idx + 3] == 0x21) &&
                                    (JTOB[idx + 4] == 0x66))
                            {
                                if ((JTOB[idx + 5] == 0x21) &&
                                    (JTOB[idx + 6] == 0x20) &&
                                    (JTOB[idx + 7] == 0x78))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 8);
                                    ptr += 8;
                                    idx += 6; // Cause idx will be increase 2 later
                                }
                                else if ((JTOB[idx + 5] == 0x22) &&
                                        (JTOB[idx + 6] == 0x21) &&
                                        (JTOB[idx + 7] == 0x76))
                                {
                                    Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 8);
                                    ptr += 8;
                                    idx += 6; // Cause idx will be increase 2 later
                                }
                            }
                        }
                        else if ((jis_ch2 == 0x26) && (idx <= length - 3))
                        {
                            // Line feed bits number designation (1/180 inch position)
                            if ((JTOB[idx + 2] == 0x10) ||
                                (JTOB[idx + 2] == 0x20) ||
                                (JTOB[idx + 2] == 0x28) ||
                                (JTOB[idx + 2] == 0x40))
                            {
                                Buffer.BlockCopy(JTOB, idx, ptr1, ptr, 3);
                                ptr += 3;
                                idx += 1; // Cause idx will be increase 2 later
                            }
                        }
                        // KI KO
                        else if ((jis_ch2 == 0x70) || (jis_ch2 == 0x71))
                        {
                            ptr1[ptr++] = jis_ch1;
                            ptr1[ptr++] = jis_ch2;
                        }
                        else
                        {
                            byte[] tempPtr = new byte[2];
                            Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2);
                            ptr1[ptr++] = tempPtr[0];
                            ptr1[ptr++] = tempPtr[1];
                        }
                    }
                    else if (jis_ch1 == 0x0D || jis_ch1 == 0x0A)
                    {
                        ptr1[ptr++] = jis_ch1;
                        idx--;
                    }
                    else
                    {
                        byte[] tempPtr = new byte[2];
                        if (Char_Jis2Big5(tempPtr, jis_ch1, jis_ch2))
                        {
                            ptr1[ptr++] = tempPtr[0];
                            ptr1[ptr++] = tempPtr[1];
                        }
                        else
                        {
                            ptr1[ptr++] = tempPtr[0];
                            idx--;
                        }
                    }
                }
            }
            
            Buffer.BlockCopy(ptr1, 0, JTOB, 0, length);
            return true;
        }

        // Convert NEC code to BIG5
        public bool Str_nec2big5(byte[] nec_to_big5, int length)
        {
            byte[] nec_code = new byte[2];
            byte nec_code_fir, nec_code_sec;
            byte[] nec_to_big5_temp = new byte[length];
            byte[] nec_to_big5_2byte = new byte[2];

            for (int idx = 0; idx < length; idx += 2)
            {
                if (idx + 1 < length)
                {
                    Buffer.BlockCopy(nec_to_big5, idx, nec_code, 0, 2);
                    nec_code_fir = nec_code[0];
                    nec_code_sec = nec_code[1];
                    
                    if (nec_code_sec < 0xA1)
                    {
                        if ((nec_code_fir >= 0x60) && (nec_code_fir <= 0x7C))
                            nec_code_fir -= 63;
                        else if (nec_code_fir == 0x7E)
                            nec_code_fir -= 64;
                        else if ((nec_code_fir >= 0x80) && (nec_code_fir <= 0x9F))
                            nec_code_fir -= 65;
                        else if ((nec_code_fir >= 0xE0) && (nec_code_fir <= 0xF9))
                            nec_code_fir -= 129;
                    }
                    else
                    {
                        if ((nec_code_fir >= 0x60) && (nec_code_fir <= 0x7C))
                            nec_code_fir += 65;
                        else if (nec_code_fir == 0x7E)
                            nec_code_fir += 64;
                        else if ((nec_code_fir >= 0x80) && (nec_code_fir <= 0x9F))
                            nec_code_fir += 63;
                        else if ((nec_code_fir >= 0xE0) && (nec_code_fir <= 0xFE))
                            nec_code_fir -= 1;
                    }
                    
                    nec_to_big5_2byte[0] = nec_code_fir;
                    nec_to_big5_2byte[1] = nec_code_sec;

                    if (Str_Jis2Big5(nec_to_big5_2byte, 2))
                        Buffer.BlockCopy(nec_to_big5_2byte, 0, nec_to_big5_temp, idx, 2);
                    else
                        Buffer.BlockCopy(Encoding.ASCII.GetBytes("  "), 0, nec_to_big5_temp, idx, 2);
                }
            }

            Buffer.BlockCopy(nec_to_big5_temp, 0, nec_to_big5, 0, length);
            return true;
        }

        // Process Chinese characters in text
        public void Comm_Chinese(byte[] input, int length)
        {
            byte[] org_ptr = input;
            int len, tmplen, flag0a;
            
            // Find KI
            int startPos = 0;
            while (startPos < length)
            {
                int kiPos = My_strstr(input, str_CHead, 2, length, startPos);
                if (kiPos == -1) break;
                
                // Find next block
                int nextBlockPos = Mystrchr(input, 0x1f, length, startPos);
                
                // Skip the KI
                Buffer.BlockCopy(input, kiPos + 2, input, kiPos, length - (kiPos + 2));
                length -= 2;
                input[length] = 0;
                input[length + 1] = 0;
                
                // Find 0x0A
                flag0a = 0;
                int lineBreakPos = Mystrchr(input, 0x0a, length, kiPos);
                
                // Find KO
                int koPos = My_strstr(input, str_CTail, 2, length, startPos);
                int blockMarkerPos = Mystrchr(input, 0x1f, length, startPos);
                
                // Process multiple KOs before KI
                while (koPos != -1 && koPos < kiPos && blockMarkerPos > koPos)
                {
                    // Skip KO
                    Buffer.BlockCopy(input, koPos + 2, input, koPos, length - (koPos + 2));
                    length -= 2;
                    kiPos -= 2;
                    input[length] = 0;
                    input[length + 1] = 0;
                    koPos = My_strstr(input, str_CTail, 2, length, startPos);
                }
                
                // Calculate length of text between KI and KO/block marker
                if (koPos != -1)
                {
                    if (lineBreakPos != -1 && lineBreakPos > koPos)
                        len = koPos - kiPos;
                    else if (lineBreakPos != -1 && lineBreakPos > kiPos)
                    {
                        len = lineBreakPos - kiPos;
                        flag0a = 1;
                    }
                    else
                        len = koPos - kiPos;
                }
                else
                {

                    if (lineBreakPos != -1 && lineBreakPos > blockMarkerPos)
                        len = blockMarkerPos - kiPos; // Not include 0x1f
                    else if (lineBreakPos != -1 && lineBreakPos > kiPos)
                    {
                        len = lineBreakPos - kiPos;
                        flag0a = 1;
                    }
                    else
                        len = blockMarkerPos - kiPos;
                }
                
                // Check for duplicate KI codes
                int dupKiPos = -1;
                while ((dupKiPos = My_strstr(input, str_CHead, 2, len, kiPos)) != -1 && koPos > dupKiPos)
                {
                    Buffer.BlockCopy(input, dupKiPos + 2, input, dupKiPos, length - (dupKiPos + 2));
                    length -= 2;
                    input[length] = 0;
                    input[length + 1] = 0;
                    koPos -= 2;
                    len -= 2;
                }
                
                // Convert the JIS code to BIG5
                byte[] segment = new byte[len];
                Buffer.BlockCopy(input, kiPos, segment, 0, len);
                Str_Jis2Big5(segment, len);
                Buffer.BlockCopy(segment, 0, input, kiPos, len);
                
                // Handle line break or KO
                if (flag0a == 1)
                {
                    // Skip past the newline
                    startPos = lineBreakPos + 1;
                }
                else if (koPos != -1)
                {
                    // Skip KO
                    Buffer.BlockCopy(input, koPos + 2, input, koPos, length - (koPos + 2));
                    length -= 2;
                    input[length] = 0;
                    input[length + 1] = 0;
                    startPos = koPos;
                }
                else
                {
                    // Move to next block
                    tmplen = nextBlockPos - startPos + 1;
                    length -= tmplen;
                    startPos = nextBlockPos + 1;
                }
            }
            
            // Clean up any remaining KO markers
            startPos = 0;
            while (true)
            {
                int koPos = My_strstr(input, str_CTail, 2, length, startPos);
                if (koPos == -1) break;
                
                Buffer.BlockCopy(input, koPos + 2, input, koPos, length - (koPos + 2));
                length -= 2;
                input[length] = 0;
            }
        }
        
        // Find a substring in a source string
        public int My_strstr(byte[] source, byte[] target, int targetLength, int sourceLength, int startPos)
        {
            for (int i = startPos; i < sourceLength - targetLength + 1; i++)
            {
                if (source[i] == target[0])
                {
                    bool found = true;
                    for (int j = 0; j < targetLength; j++)
                    {
                        if (source[i + j] != target[j])
                        {
                            found = false;
                            break;
                        }
                    }
                    if (found)
                    {
                        return i;
                    }
                }
            }
            return -1;
        }
        
        // Check if a code is in Chinese character area
        public bool Chinese_area(byte[] Code)
        {
            byte HI = Code[0], LO = Code[1];
            
            if (HI >= 0x81 && HI <= 0xFE)
            {
                if ((LO >= 0x40 && LO <= 0x7E) || (LO >= 0x80 && LO <= 0xA0) || (LO >= 0xA1 && LO <= 0xFE))
                    return true; // MODIFY FOR BIG-5E
                else
                    return false;
            }
            else
                return false;
        }
        
        // Check if a code is in JIS area
        public bool Jis_area(byte[] Code)
        {
            byte HI = Code[0], LO = Code[1];
            
            if ((HI >= 0x21 && HI <= 0x7E) || (HI >= 0xA1 && HI <= 0xFE))
            {
                if ((LO >= 0x21 && LO <= 0x7E) || (LO >= 0xA1 && LO <= 0xFE))
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        
        // Convert BIG5 to JIS
        public void BigToJis(byte[] ccode)
        {
            ushort wBig5;
            ushort wJisHigh = (ushort)(ccode[0] & 0xff);
            ushort wJisLow = (ushort)(ccode[1] & 0xff);
            ccode[0] = 0;    // Added by tclmk
            ccode[1] = 0;    //
            wBig5 = (ushort)(((wJisHigh & 0x00ff) << 8) | ((wJisLow & 0x00ff)));
            
            // Convert internal character
            wJisHigh -= 0x81;
            wJisLow -= 0x40;
            ushort num = (ushort)(wJisHigh * 191 + wJisLow);
            
            // Temporary solution
            if (num > MAXWORDNUM)
            {
                num = 0;
            }
            
            ccode[0] = (byte)(jistbl[num]);
            ccode[1] = (byte)(jistbl[num] >> 8);
            
            // Ensure we don't fill in NULL, convert to = added by tclmk
            if (ccode[1] == 0)
                ccode[1] = 0x57;
            if (ccode[0] == 0)
                ccode[0] = 0x21;
        }
        
        // Convert BIG5 string to JIS
        public void Str_BigToJis(byte[] source, int length)
        {
            for (int idx = 0; idx < length; idx++)
            {
                if (!Chinese_area(new byte[] { source[idx], idx + 1 < length ? source[idx + 1] : (byte)0 }))
                    continue;
                else
                {
                    byte[] temp = new byte[] { source[idx], source[idx + 1] };
                    BigToJis(temp);
                    source[idx] = temp[0];
                    source[idx + 1] = temp[1];
                    idx++; // 2 bytes
                }
            }
        }
        
        // Find a byte in a buffer
        public int Mystrchr(byte[] source, byte chr, int length, int startPos)
        {
            for (int idx = startPos; idx < length; idx++)
            {
                if (source[idx] == chr)
                {
                    return idx;
                }
            }
            return -1;
        }
    }
}
