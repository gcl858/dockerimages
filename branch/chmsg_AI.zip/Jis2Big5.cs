/****************************************************************
 * Name: JIS2BIG5.cs
 *
 * Description:
 *    Converting the jis-string to big5 code
 *
 * created by Pack Hsieh
 * Converted to C# version
 *
 */

using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Diagnostics;

namespace Nbt.Sdk72.ChostMessage
{
    public class JIS2BIG5
    {
        private const int MAXWORDNUM = 35000;

        private byte[] str_CHead = new byte[] { 0x1A, 0x70, 0 };
        private byte[] str_CTail = new byte[] { 0x1A, 0x71, 0 };
        private static UInt16[] bigtbl = new UInt16[MAXWORDNUM];
        private static UInt16[] jistbl = new UInt16[MAXWORDNUM];

        private byte[] neccode_tab_buffer;

        /// <summary>
        /// 建構子，讀取轉換表
        /// </summary>
        public JIS2BIG5()
        {
            neccode_tab_buffer = null;

            FileStream fbig = null;
            FileStream fjis = null;

            try
            {
                fbig = new FileStream("jistobig5.tbl", FileMode.Open, FileAccess.Read);
                fjis = new FileStream("big5tojis.tbl", FileMode.Open, FileAccess.Read);

                if (fbig == null && fjis == null)
                {
                    MessageBox("Can't find JIS <---> BIG5 table!");
                    Environment.Exit(0);
                }
                else
                {
                    if (fbig != null)
                    {
                        Array.Clear(bigtbl, 0, bigtbl.Length);
                        byte[] buffer = new byte[MAXWORDNUM * 2];
                        fbig.Read(buffer, 0, buffer.Length);
                        
                        for (int i = 0; i < MAXWORDNUM; i++)
                        {
                            bigtbl[i] = BitConverter.ToUInt16(buffer, i * 2);
                        }
                        fbig.Close();
                    }

                    if (fjis != null)
                    {
                        Array.Clear(jistbl, 0, jistbl.Length);
                        byte[] buffer = new byte[MAXWORDNUM * 2];
                        fjis.Read(buffer, 0, buffer.Length);
                        
                        for (int i = 0; i < MAXWORDNUM; i++)
                        {
                            jistbl[i] = BitConverter.ToUInt16(buffer, i * 2);
                        }
                        fjis.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading JIS/BIG5 tables: " + ex.Message);
            }
            finally
            {
                if (fbig != null) fbig.Dispose();
                if (fjis != null) fjis.Dispose();
            }
        }

        /// <summary>
        /// 析構子，釋放資源
        /// </summary>
        ~JIS2BIG5()
        {
            neccode_tab_buffer = null;
        }

        /// <summary>
        /// 檢查 ESC 序列並進行轉換
        /// </summary>
        public void CheckESCsequence(byte[] buffer, int length)
        {
            byte[] ptr = buffer;

            for (int idx = 0; idx <= length; idx++)
            {
                if (idx >= buffer.Length) break;

                if (ptr[idx] == 0x1b)
                {
                    if (idx + 2 >= buffer.Length) break;

                    switch (ptr[idx + 1])
                    {
                        case 0x50: // P
                            if (ptr[idx + 2] >= 0x44 && ptr[idx + 2] <= 0x5F)
                                ptr[idx + 2] = (byte)(ptr[idx + 2] - 4);
                            break;

                        case 0x51: // Q
                        case 0x52: // R
                            if (ptr[idx + 2] >= 0x44 && ptr[idx + 2] <= 0x5F)
                            {
                                ptr[idx + 2] = (byte)(ptr[idx + 2] - 4);
                            }
                            else if (ptr[idx + 2] <= 0x43)
                            {
                                ptr[idx + 1] = (byte)(ptr[idx + 1] - 1);
                                ptr[idx + 2] = (byte)(0x5C + (0x43 - ptr[idx + 2]));
                            }
                            break;

                        case 0x53: // S
                        case 0x54: // T
                        case 0x55: // U
                            if (ptr[idx + 2] >= 0x40 && ptr[idx + 2] <= 0x5F)
                                ptr[idx + 1] = (byte)(ptr[idx + 1] - 3);
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// 檢查水平控制碼，修正 ITP1 控制碼
        /// </summary>
        public void CheckHorizonCtl(byte[] buffer, ref uint length)
        {
            int len, idx;
            byte[] newbuffer = new byte[5120];

            if (length > newbuffer.Length)
                return;

            Array.Clear(newbuffer, 0, newbuffer.Length);

            idx = len = 0;

            while (idx < (int)length)
            {
                if (buffer[idx] == 0x1b &&
                    (buffer[idx + 1] >= 0x50) && (buffer[idx + 1] <= 0x55))
                {
                    newbuffer[len++] = 0x0D; // line feed，將控制碼移到最前端
                    newbuffer[len++] = buffer[idx];
                    idx++;
                }
                else
                {
                    newbuffer[len++] = buffer[idx];
                    idx++;
                }
            }

            Array.Copy(newbuffer, 0, buffer, 0, len);
            // 更改長度
            length = (uint)len;
        }

        /// <summary>
        /// 將 ITP1 控制碼轉換為 dummy code
        /// </summary>
        public int DummyESCsequence(byte[] buffer, int length)
        {
            int idx, len;
            byte[] newbuffer = new byte[5120];
            
            Array.Clear(newbuffer, 0, newbuffer.Length);
            len = 0;

            for (idx = 0; idx < length; idx++)
            {
                if (buffer[idx] == 0x1b)
                {
                    if (idx + 1 >= buffer.Length) break;
                    
                    switch (buffer[idx + 1])
                    {
                        case 0x31: // 1
                        case 0x32: // 2
                        case 0x33: // 3
                        case 0x34: // 4
                        case 0x28: // (
                        case 0x29: // )
                            idx++;
                            idx++;
                            break;
                            
                        // 其他 ESC 序列處理，略過控制碼
                        case 0x23: //# 8,9
                            if ((buffer[idx + 2] >= 0x38) && (buffer[idx + 2] <= 0x39))
                            {
                                idx += 2;
                                idx += 3;
                            }
                            break;
                        case 0x5f: //- Q,R,T,U
                            if ((buffer[idx + 2] >= 0x51) && (buffer[idx + 2] <= 0x55) && (buffer[idx + 2] != 0x53))
                            {
                                idx += 2;
                                idx += 3;
                            }
                            break;
                        case 0x58: //x A ~ _
                            if ((buffer[idx + 2] >= 0x41) && (buffer[idx + 2] <= 0x5f))
                            {
                                idx += 2;
                                idx += 3;
                            }
                            break;
                        case 0x59: //Y @ ~ _
                            if ((buffer[idx + 2] >= 0x40) && (buffer[idx + 2] <= 0x5F))
                            {
                                idx += 2;
                                idx += 3;
                            }
                            break;
                        case 0x50:	//P @ ~ _
                        case 0x51:	//Q @ ~ _
                        case 0x52:	//R @ ~ _
                            if (buffer[idx + 2] >= 0x40 && buffer[idx + 2] <= 0x5F)
                            {
                                idx += 2;
                                idx += 3;
                            }
                            break;
                        case 0x53:	//S @ ~ M
                            if (buffer[idx + 2] >= 0x40 && buffer[idx + 2] <= 0x4d)
                            {
                                idx += 2;
                                idx += 3;
                            }
                            break;
                        case 0x63:	//63H 8
                            if (buffer[idx + 2] == 0x38)
                            {
                                idx += 2;
                                idx += 3;
                            }
                            break;
                        default:
                            idx++;
                            break;
                    }
                }
                else
                {
                    newbuffer[len++] = buffer[idx];
                    if (newbuffer[len-1] == 0)
                        newbuffer[len-1] = 0x20;
                }
            }
            
            Array.Clear(buffer, 0, length);
            Array.Copy(newbuffer, 0, buffer, 0, length);
            return len;
        }

        /// <summary>
        /// 將單個 JIS 字元轉換為 Big5 字元
        /// </summary>
        public bool Char_Jis2Big5(byte[] ptr, byte jis_ch1, byte jis_ch2)
        {
            byte ch1, ch2;
            int c1, c2, num;
            byte[] Jis = new byte[2];
            
            Jis[0] = jis_ch1;
            Jis[1] = jis_ch2;
            
            if (Jis[0] >= 0x21 && Jis[0] <= 0x7e && Jis[1] >= 0x21 && Jis[1] <= 0x7e)
            {
                c1 = (Jis[0] - 0x21) * 94;
                c2 = Jis[1] - 0x21;
                num = c1 + c2;
                
                if (num < MAXWORDNUM && bigtbl[num] != 0)
                {
                    ch1 = (byte)((bigtbl[num] >> 8) & 0xFF);
                    ch2 = (byte)(bigtbl[num] & 0xFF);
                    
                    ptr[0] = ch1;
                    ptr[1] = ch2;
                    return true;
                }
            }
            
            // 無法轉換的情況，使用空格代替
            ptr[0] = 0x20;
            ptr[1] = 0x20;
            return false;
        }

        /// <summary>
        /// 將 JIS 編碼字串轉換為 Big5 編碼
        /// </summary>
        public int Jis2Big5(byte[] buffer, int length)
        {
            int idx = 0, ch_idx = 0;
            byte[] newbuffer = new byte[5120];
            byte[] tptr = new byte[2];
            
            Array.Clear(newbuffer, 0, newbuffer.Length);
            
            while (idx < length)
            {
                if (buffer[idx] >= 0x21 && buffer[idx] <= 0x7E && 
                    idx + 1 < length && buffer[idx + 1] >= 0x21 && buffer[idx + 1] <= 0x7E)
                {
                    // JIS 雙位元組字元
                    if (Char_Jis2Big5(tptr, buffer[idx], buffer[idx + 1]))
                    {
                        newbuffer[ch_idx++] = tptr[0];
                        newbuffer[ch_idx++] = tptr[1];
                    }
                    else
                    {
                        // 轉換失敗，使用空格
                        newbuffer[ch_idx++] = 0x20;
                    }
                    idx += 2;
                }
                else if (buffer[idx] == 0x1B)
                {
                    // ESC 序列，跳過
                    idx++;
                    if (idx < length - 1)
                    {
                        idx += 2;
                    }
                }
                else
                {
                    // 單位元組字元
                    newbuffer[ch_idx++] = buffer[idx++];
                }
            }
            
            Array.Copy(newbuffer, 0, buffer, 0, ch_idx);
            return ch_idx;
        }

        /// <summary>
        /// 將 Big5 字元轉換為 JIS 字元
        /// </summary>
        public bool Char_Big5ToJis(byte[] ptr, byte big5_ch1, byte big5_ch2)
        {
            int num;
            UInt16 big;
            
            big = (UInt16)((big5_ch1 << 8) | big5_ch2);
            
            // 在轉換表中查找
            for (num = 0; num < MAXWORDNUM; num++)
            {
                if (bigtbl[num] == big)
                {
                    ptr[0] = (byte)((num / 94) + 0x21);
                    ptr[1] = (byte)((num % 94) + 0x21);
                    return true;
                }
            }
            
            // 使用查表法直接查找
            num = (((big5_ch1 - 0xA1) & 0x7F) * 157) + ((big5_ch2 - 0x40) & 0xFF);
            if (num < MAXWORDNUM && jistbl[num] != 0)
            {
                ptr[0] = (byte)((jistbl[num] >> 8) & 0xFF);
                ptr[1] = (byte)(jistbl[num] & 0xFF);
                return true;
            }
            
            // 無法轉換的情況
            ptr[0] = 0x20;
            ptr[1] = 0x20;
            return false;
        }

        /// <summary>
        /// 將 Big5 編碼字串轉換為 JIS 編碼
        /// </summary>
        public int Big5ToJis(byte[] buffer, int length)
        {
            int idx = 0, ch_idx = 0;
            byte[] newbuffer = new byte[5120];
            byte[] tptr = new byte[2];
            
            Array.Clear(newbuffer, 0, newbuffer.Length);
            
            while (idx < length)
            {
                if ((buffer[idx] >= 0xA1 && buffer[idx] <= 0xFE) || 
                    (buffer[idx] >= 0x81 && buffer[idx] <= 0xA0))
                {
                    // Big5 雙位元組字元
                    if (idx + 1 < length)
                    {
                        if (Char_Big5ToJis(tptr, buffer[idx], buffer[idx + 1]))
                        {
                            // 加入 JIS 標記
                            if (ch_idx + 2 < newbuffer.Length)
                            {
                                Array.Copy(str_CHead, 0, newbuffer, ch_idx, 2);
                                ch_idx += 2;
                            }
                            
                            newbuffer[ch_idx++] = tptr[0];
                            newbuffer[ch_idx++] = tptr[1];
                            
                            // 加入結束標記
                            if (ch_idx + 2 < newbuffer.Length)
                            {
                                Array.Copy(str_CTail, 0, newbuffer, ch_idx, 2);
                                ch_idx += 2;
                            }
                        }
                        else
                        {
                            // 轉換失敗，使用空格
                            newbuffer[ch_idx++] = 0x20;
                        }
                        idx += 2;
                    }
                    else
                    {
                        // 不完整的雙位元組，使用空格
                        newbuffer[ch_idx++] = 0x20;
                        idx++;
                    }
                }
                else
                {
                    // 單位元組字元
                    newbuffer[ch_idx++] = buffer[idx++];
                }
            }
            
            Array.Copy(newbuffer, 0, buffer, 0, ch_idx);
            return ch_idx;
        }

        /// <summary>
        /// 處理中文字符，轉換 KI 和 KO 控制碼之間的 JIS 碼
        /// </summary>
        public void CommChinese(byte[] input, int length)
        {
            byte[] orgPtr = input;
            int tmpLen, flag0a;
            
            // 尋找 KI 控制碼 (str_CHead)
            byte[] ptr = null;
            while ((ptr = MyStrStr(input, str_CHead, 2, length)) != null)
            {
                // 尋找下一個區塊
                byte[] ptr3 = MyStrchr(input, 0x1f, length);
                
                // 跳過 KI 控制碼
                int ptrOffset = ptr - input;
                Array.Copy(input, ptrOffset + 2, input, ptrOffset, length - (ptrOffset + 2));
                length -= 2;
                input[length] = 0;
                input[length + 1] = 0;
                
                // 尋找 0x0A
                flag0a = 0;
                byte[] ptr0a = MyStrchr(ptr, 0x0a, length);
                
                // 尋找 KO 控制碼
                byte[] ptr1 = MyStrStr(input, str_CTail, 2, length);
                byte[] ptr2 = MyStrchr(input, 0x1f, length);
                
                // 處理重複的 KO 控制碼
                while (ptr1 != null && ptr1 < ptr && ptr2 > ptr1)
                {
                    // 跳過 KO 控制碼
                    int ptr1Offset = ptr1 - input;
                    Array.Copy(input, ptr1Offset + 2, input, ptr1Offset, length - (ptr1Offset + 2));
                    length -= 2;
                    ptr = ptr - 2;
                    input[length] = 0;
                    input[length + 1] = 0;
                    ptr1 = MyStrStr(input, str_CTail, 2, length);
                }
                
                int len;
                if (ptr1 != null)
                {
                    if (ptr0a > ptr1)
                        len = ptr1 - ptr;
                    else if (ptr0a > ptr)
                    {
                        len = ptr0a - ptr;
                        flag0a = 1;
                    }
                    else
                        len = ptr1 - ptr;
                }
                else
                {
                    if (ptr0a > ptr2)
                        len = ptr2 - ptr; // 不包含 0x1f
                    else if (ptr0a > ptr)
                    {
                        len = ptr0a - ptr;
                        flag0a = 1;
                    }
                    else
                        len = ptr2 - ptr;
                }
                ptr2 = null;
                
                // 如果發現重複的 KI 控制碼，則跳過
                while ((ptr2 = MyStrStr(ptr, str_CHead, 2, len)) != null && ptr1 > ptr2)
                {
                    int ptr2Offset = ptr2 - input;
                    Array.Copy(input, ptr2Offset + 2, input, ptr2Offset, length - (ptr2Offset + 2));
                    length -= 2;
                    input[length] = 0;
                    input[length + 1] = 0;
                    ptr1 = ptr1 - 2;
                    len -= 2;
                }
                
                // 處理 2 位元組編碼
                str_Jis2Big5(ptr, len);
                
                if (flag0a == 1)
                {
                    input = input.Skip(1).ToArray();
                    length--;
                }
                // 跳過 KO 控制碼
                else if (ptr1 != null)
                {
                    int ptr1Offset = ptr1 - input;
                    Array.Copy(input, ptr1Offset + 2, input, ptr1Offset, length - (ptr1Offset + 2));
                    length -= 2;
                    input[length] = 0;
                    input[length + 1] = 0;
                }
                else
                {
                    // 指向下一個區塊
                    tmpLen = ptr3 - input + 1;
                    length -= tmpLen;
                    input = ptr3.Skip(1).ToArray();
                }
            }
            
            // 處理剩餘的 KO 控制碼
            while ((ptr = MyStrStr(input, str_CTail, 2, length)) != null)
            {
                int ptrOffset = ptr - input;
                Array.Copy(input, ptrOffset + 2, input, ptrOffset, length - (ptrOffset + 2));
                length -= 2;
                input[length] = 0;
            }
            
            input = orgPtr;
        }
        
        /// <summary>
        /// 從源字串中查找目標子字串
        /// </summary>
        public byte[] MyStrStr(byte[] source, byte[] target, int targetLength, int sourceLength)
        {
            byte[] sptr = source;
            
            while (sourceLength > 0)
            {
                if (sptr[0] == target[0])
                {
                    bool match = true;
                    for (int i = 0; i < targetLength; i++)
                    {
                        if (i >= sourceLength || sptr[i] != target[i])
                        {
                            match = false;
                            break;
                        }
                    }
                    
                    if (match)
                        return sptr;
                }
                
                sptr = sptr.Skip(1).ToArray();
                sourceLength--;
            }
            
            return null;
        }
        
        /// <summary>
        /// 在源字串中查找指定字符
        /// </summary>
        public byte[] MyStrchr(byte[] source, byte chr, int length)
        {
            for (int idx = 0; idx < length; idx++)
            {
                if (source[idx] == chr)
                {
                    return source.Skip(idx).ToArray();
                }
            }
            
            return null;
        }
        
        /// <summary>
        /// 將 JIS 編碼字節轉換為 Big5 編碼
        /// </summary>
        private bool str_Jis2Big5(byte[] ptr, int len)
        {
            for (int idx = 0; idx < len; idx += 2)
            {
                if (idx + 1 < len)
                {
                    if (Char_Jis2Big5(new byte[2], ptr[idx], ptr[idx + 1]))
                    {
                        // 轉換成功
                    }
                }
            }
            
            return true;
        }

        /// <summary>
        /// 顯示訊息框的輔助方法
        /// </summary>
        private void MessageBox(string message)
        {
            Console.WriteLine(message);
            // 實際實現可能需要根據使用環境調整
        }
    }
}