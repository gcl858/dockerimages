DWORD CHostMessage::EditHostMessage(BYTE anotherPage, LPVOID lpvHostMessage, LPDWORD lpdwResultLength)

{

    CmTradeJournal* lpCmTradeJournal;

	WORD	wFlag = 0;

    static  CHAR    lpszFuncName[] = "CHostMessage::EditHostMessage";

/////////////////////////////

// added by Pack Hsieh

	WINXMONDATA	*pMonData = NULL;

	INT			iAllMonNumber = 0;

	BOOL		bReturn;

	INT			cnt;

	BYTE		byInputLength;

	WORD		Length;

	BYTE		sBaseData[55];
	CHAR		sBaseDataJSON[512]; // 新增一個用來存儲JSON格式資料的變數

	int			idx = 0;

	BYTE		tmpbuf[16];

	BYTE		Data[16];

	CHAR		szBrno[33];

	char		strData[100];

//	JIS2BIG5	jisbig;				// 轉碼 CLASS



    ZeroMemory(szBrno, sizeof(szBrno));

	m_PrevNextPage = 0;



    // Entry�g���[�X

	COMN_TraceWrite(&wFlag, TRACELEVEL_6,lpszFuncName,0);



	// 初期化

    ZeroMemory(m_szCentr_tran_no, sizeof(m_szCentr_tran_no));



	// Journal Object Pointer取得

    lpCmTradeJournal = CmTradeJournal::GetObjectPointer(CmTradeJournal::READ_WRITE);

    if(NULL == lpCmTradeJournal)

        COMN_EventReportErrINCON(0,0,NULL,

            lpszFuncName,"CmTradeJournal::GetObjectPointer Error");



	m_szCentr_tran_no[0] = 'P';

	// 上行電文Data

    if(FALSE == lpCmTradeJournal->GetItemData(JN_CENTR_TRAN_NO, &m_szCentr_tran_no[1]))

        COMN_EventReportErrINCON(0,0,NULL,

            lpszFuncName,"CmTradeJournal->GetItemData JN_CENTR_TRAN_NO Error");

    // 



    ZeroMemory(sBaseData, sizeof(sBaseData));
    memset(sBaseDataJSON, 0, sizeof(sBaseDataJSON)); // 初始化JSON字串
    strcat(sBaseDataJSON, "{"); // 開始JSON格式
	sBaseData[idx++] = 'P';
    strcat(sBaseDataJSON, "\"TransactionType\":\"P\","); // 將交易類型加入JSON

	//get 機號
    if(FALSE == lpCmTradeJournal->GetItemData(JN_TERM_NO, &sBaseData[idx++]))
        COMN_EventReportErrINCON(0,0,NULL,lpszFuncName,"CmTradeJournal->GetItemData JN_TERM_NO Error");
    else {
        char tmpJSON[32] = {0};
        sprintf(tmpJSON, "\"TerminalNo\":\"%c\",", sBaseData[idx-1]);
        strcat(sBaseDataJSON, tmpJSON);
    }

	// 處理序號
	ZeroMemory(tmpbuf, sizeof(tmpbuf));
	m_lpCmCenterNumber->GetNumber((char *)tmpbuf);
	CopyMemory(&sBaseData[idx], tmpbuf, 4);
    {
        char tmpJSON[64] = {0};
        sprintf(tmpJSON, "\"SerialNo\":\"%s\",", tmpbuf);
        strcat(sBaseDataJSON, tmpJSON);
    }
	idx += 4;

	////////////////////////////////////////
	//CB1, CB2, 代\教, 上下頁
	sBaseData[idx++] = '@';
    strcat(sBaseDataJSON, "\"Symbol\":\"@\",");
    
	if (TRUE == GetTeiseiAddInfo()) {
		sBaseData[idx++] = 'B'; //A:正常  B:更正
        strcat(sBaseDataJSON, "\"Status\":\"B\","); // B:更正
    } else {
		sBaseData[idx++] = 'A'; //A:正常  B:更正
        strcat(sBaseDataJSON, "\"Status\":\"A\","); // A:正常
    }

	if (GetDAIKOAddInfo(szBrno)) { //代行
		sBaseData[idx++] = '1';
        strcat(sBaseDataJSON, "\"SpecialType\":\"1\","); // 代行
	} else if (GetKYOUIKUAddInfo()) { //教育
		sBaseData[idx++] = '2';
        strcat(sBaseDataJSON, "\"SpecialType\":\"2\","); // 教育
	} else {
		sBaseData[idx++] = 0x20; //正常
        strcat(sBaseDataJSON, "\"SpecialType\":\" \","); // 正常
    }

	if (anotherPage) {
		sBaseData[idx++] = 0x30 + anotherPage; //上下頁
        char tmpJSON[32] = {0};
        sprintf(tmpJSON, "\"Page\":\"%c\",", (0x30 + anotherPage));
        strcat(sBaseDataJSON, tmpJSON);
	} else {
		sBaseData[idx++] = 0x20; //上下頁
        strcat(sBaseDataJSON, "\"Page\":\" \",");
    }

	//trxdate
    ZeroMemory(tmpbuf, sizeof(tmpbuf));
    if(FALSE == lpCmTradeJournal->GetItemData(JN_TRADE_DATE, tmpbuf))
        COMN_EventReportErrINCON(0,0,NULL,lpszFuncName,"CmTradeJournal->GetItemData JN_TRADE_DATE Error");
	tmpbuf[8] = 0;
	CHAR strYear[5], strDate[5];
	memcpy(strYear, tmpbuf, 4);
	memcpy(strDate, &tmpbuf[4], 4);
	strYear[4] = 0;
	strDate[4] = 0;
	INT	mYear = atoi((char *)strYear) - 1911;
	//add by TonyChen 民國百年顯示 980728 
	if ( mYear >= 100) 
	{
		mYear=mYear-100;
	}
	//ended by TonyChen 民國百年顯示 980728

    ZeroMemory(tmpbuf, sizeof(tmpbuf));
	sprintf((char *)tmpbuf, "%02d%s", mYear, (char *)strDate);
	CopyMemory(&sBaseData[idx], tmpbuf, 6);
    {
        char tmpJSON[64] = {0};
        sprintf(tmpJSON, "\"TransactionDate\":\"%s\",", tmpbuf);
        strcat(sBaseDataJSON, tmpJSON);
    }
	idx += 6;

	//trx Screen NO.
    ZeroMemory(tmpbuf, sizeof(tmpbuf));
    if(FALSE == lpCmTradeJournal->GetItemData(JN_TRAN_NO, tmpbuf))
        COMN_EventReportErrINCON(0,0,NULL,lpszFuncName,"CmTradeJournal->GetItemData JN_TRAN_NO Error");
	tmpbuf[8] = 0;
	memcpy(&sBaseData[idx], &tmpbuf[3], 5);
	memcpy(prn_scrno,tmpbuf,9); //add tclmk for 一般印表
    {
        char tmpJSON[64] = {0};
        sprintf(tmpJSON, "\"ScreenNo\":\"%s\",", &tmpbuf[3]);
        strcat(sBaseDataJSON, tmpJSON);
    }
	idx += 5;



	//operator code

    ZeroMemory(tmpbuf, sizeof(tmpbuf));

    if(FALSE == lpCmTradeJournal->GetItemData(JN_OPERATOR_NO, tmpbuf))

        COMN_EventReportErrINCON(0,0,NULL,lpszFuncName,"CmTradeJournal->GetItemData JN_TERM_NO Error");



	if ((tmpbuf[0] == 0) || (tmpbuf[0] == 0X20) || (tmpbuf[1] == 'D') ){

		tmpbuf[0] = 'O';  //無opkey   OD key 為維護員key

		tmpbuf[1] = '@';  //無opkey



		CHAR SGbrno[7];				//SG分行

		CHAR Tmp_SGbrno[7];			//SG分行

		DWORD dwReadLength = 0;

		memset(SGbrno, 0, sizeof(SGbrno));

		memset(Tmp_SGbrno, 0, sizeof(Tmp_SGbrno));

	// 取得SG分行代碼

//		dwReadLength = CmDevice::GetBranchNo(SGbrno);

		dwReadLength = CmDevice::GetBranchNo(Tmp_SGbrno);		// 取得分行代碼

		if (dwReadLength > BRANCH_LEN) {			

			memcpy(SGbrno,Tmp_SGbrno+(dwReadLength-BRANCH_LEN),BRANCH_LEN);  //tclmk 20031117

			dwReadLength = BRANCH_LEN;

		}

		else 

			memcpy(SGbrno,Tmp_SGbrno,dwReadLength);



		if((memcmp(SGbrno, "070", 3) == 0) || (memcmp(SGbrno, "950", 3) >= 0))

			jisbig.Opkeyprocess(tmpbuf); //070,998,999 未接card reader 時以lgogin user代替

	}

	else

		tmpbuf[2] = 0;

    memcpy(&sBaseData[idx], tmpbuf, 2);
    {
        char tmpJSON[32] = {0};
        sprintf(tmpJSON, "\"OperatorCode\":\"%c%c\",", tmpbuf[0], tmpbuf[1]);
        strcat(sBaseDataJSON, tmpJSON);
    }

	idx += 2;



    memset(&sBaseData[idx], 0x20, 10);
    strcat(sBaseDataJSON, "\"Filler\":\"          \","); // 添加10個空格的填充欄位

	idx += 10;



	//master code

    ZeroMemory(tmpbuf, sizeof(tmpbuf));

    if(FALSE == lpCmTradeJournal->GetItemData(JN_MANAGER_NO, tmpbuf))

        COMN_EventReportErrINCON(0,0,NULL,lpszFuncName,"CmTradeJournal->GetItemData JN_TERM_NO Error");

/*	if (tmpbuf[0] == 0){

		tmpbuf[0] = 'M';  //主管key

		tmpbuf[1] = '@';  //無主管key

	}

	else

		tmpbuf[2] = 0; */

	if (tmpbuf[0] == 'M') {

	   if (tmpbuf[1] < 'Q' || tmpbuf[1] > 'Z') {

	      tmpbuf[0] = 'M';  //主管key

	      tmpbuf[1] = '@';  //無主管key

	   }

	}

	else {

	   tmpbuf[0] = 'M';  //主管key

	   tmpbuf[1] = '@';  //無主管key

	}

	tmpbuf[2] = 0;

    memcpy(&sBaseData[idx], tmpbuf, 2);
    {
        char tmpJSON[32] = {0};
        sprintf(tmpJSON, "\"ManagerCode\":\"%c%c\",", tmpbuf[0], tmpbuf[1]);
        strcat(sBaseDataJSON, tmpJSON);
    }

	idx += 2;





	//filler

	memset(&sBaseData[idx], 0x20, 10);
    strcat(sBaseDataJSON, "\"Filler2\":\"          \","); // 添加第二個10個空格的填充欄位
	idx += 10;



	//////////////////////////////////////////

	//brno

	//是否代行

	if ((szBrno[0] == 0) || (szBrno[0] == 0x20)){

	    ZeroMemory(tmpbuf, sizeof(tmpbuf));

		if(FALSE == lpCmTradeJournal->GetItemData(JN_BRANCH_CODE, tmpbuf))

			COMN_EventReportErrINCON(0,0,NULL,lpszFuncName,"CmTradeJournal->GetItemData JN_TERM_NO Error");

/*	marked by gcl858 20040430 for 分行代號如0530998 取後3碼

		if (tmpbuf[0] == 0)

			memset(tmpbuf, 0x20, 3);

		else

			tmpbuf[3] = 0;

		memcpy(&sBaseData[idx], tmpbuf, 3);

*/

//added by gcl858 20040430 for 分行代號如0530998 取後3碼

		if (tmpbuf[0] == 0)

		{

			memset(tmpbuf, 0x20, 3);

			memcpy(&sBaseData[idx], tmpbuf, 3);
            {
                char tmpJSON[32] = {0};
                sprintf(tmpJSON, "\"BranchNo\":\"%s\",", "   "); // Fill with spaces initially
                strcat(sBaseDataJSON, tmpJSON);
            }
		}

		else

		{			
            char BranchNo[16];
            memcpy(BranchNo,tmpbuf,sizeof(BranchNo));
            memcpy(&sBaseData[idx], BranchNo+strlen(BranchNo)-3, 3);
            {
                char tmpJSON[32] = {0};
                sprintf(tmpJSON, "\"BranchNo\":\"%s\",", BranchNo+strlen(BranchNo)-3);
                strcat(sBaseDataJSON, tmpJSON);
            }
		}

//end added 



	}

	else{

		szBrno[3] = 0;

		memcpy(&sBaseData[idx], szBrno, 3);
        {
            char tmpJSON[32] = {0};
            sprintf(tmpJSON, "\"BranchNo\":\"%s\",", szBrno);
            strcat(sBaseDataJSON, tmpJSON);
        }
	}

	idx += 3;

/*	memset(&sBaseData[idx], 0x20, 5);

	idx += 5;         modify tclmk for itp1 未接    */

	memset(&sBaseData[idx], 0x20, 1);		// add tclmk
    // Add the filler value to JSON
    strcat(sBaseDataJSON, "\"Filler3\":\" \",");
	idx++;

	m_lpCmMtpLPH = CmMtpLPH::GetObjectPointer(); 

	if(NULL != m_lpCmMtpLPH) {					

		memset(&sBaseData[idx], 0x20, 1);	

	}

	else

		memset(&sBaseData[idx], 0x32, 1);	//BPR=2 未接

	idx++;

	memset(&sBaseData[idx], 0x20, 3);

    idx += 3;								//add tclmk
    strcat(sBaseDataJSON, "\"Filler4\":\"   \",");  // Add 3-space filler to JSON

	sBaseData[idx++] = 0X1F;
    
    // 完成JSON格式
    // 移除最後的逗號並添加結束括號
    int jsonLen = strlen(sBaseDataJSON);
    if (sBaseDataJSON[jsonLen-1] == ',') {
        sBaseDataJSON[jsonLen-1] = '}';
    } else {
        strcat(sBaseDataJSON, "}");
    }

	memcpy(sToHost, sBaseData, idx);
	place = idx;

	bReturn = GetAllMonData(&pMonData, &iAllMonNumber);

	////////////////////////////////////////////////////////

	// 1. 上行電文項目番號定義

	//		一般輸入項目:Gmtori		Spring輸入項目:Gmsprng

	// 2. 上行電文小數部編輯位數定義

	//		一般輸入項目:Gmtori		Spring輸入項目:Gmsprng

	//		若已有輸入小數,則依輸入為準,不再編入

	//		否則自動填入 ".0000....."

	// 3. 上行電文編輯位數(含上行電文小數部編輯位數)

	//		一般輸入項目: Gmtori	Spring輸入項目:Gmsprng

	//		a. 若 (輸入資料 + 小數部) < 上行電文編輯位數(定義於畫面輸入項目), 則前面補 '0'

	//		b. 若 (輸入資料 + 小數部) > 上行電文編輯位數(定義於畫面輸入項目), 則前面刪除

	// 4. 上行電文小數部編輯位數定義

	//		一般輸入項目: Gmtori	Spring輸入項目:Gmsprng

	// 5. 輸入資料之前的空白不予編入

	// 6. 摘要鍵定義於[特殊資訊-預備欄位]內容須設定為 A

	// 7. 保留存摺行數定義於[特殊資訊-預備欄位]內容須設定為 B

	//    (將存摺行數不用磁條而用手工輸入時使用)

	// 8. 輸入資料之前的空白不清除,[特殊資訊-預備欄位]內容須設定為 C

	//    (如   123;編輯後仍為   123)

	// 9. 轉換摘要鍵代碼 1 --> A 現金

	//					 2 --> B 轉帳

	//					 3 --> D 摘要

	//					 4 --> I 合計

	//					 5 --> K 票據

	int springCashAmount=0;
	int springCheckAmount=0;
	int springCheckTOTALAmount=0; 
    int springTOTALAmount=0; 
	bool bSpringPass = 0;
	CTrWindows     *CTRWIN_OBJPTR;  
	KinsyuMonitorItem  MonitorItem;
	int            ret  = 0;

	for (cnt = 0; cnt < iAllMonNumber; cnt++){
        //added by TonyChen for現金處理機 990125
		bSpringPass = 0;
        CTRWIN_OBJPTR = CTrWindows::GetObjectPointer();
        //上行電文項目番號置換
		if(((pMonData + cnt)->szTelNo[0]=='F' && (pMonData + cnt)->szTelNo[1]=='2' && (pMonData + cnt)->szTelNo[2]=='1') ||
		   ((pMonData + cnt)->szTelNo[0]=='F' && (pMonData + cnt)->szTelNo[1]=='0' && (pMonData + cnt)->szTelNo[2]=='2'))
		{
			(pMonData + cnt)->szTelNo[0]='0' ;
			(pMonData + cnt)->szTelNo[1]='1' ;
			(pMonData + cnt)->szTelNo[2]='5' ;
			// 抓取spring金額資訊
			CTRWIN_OBJPTR->Lock();
			ret = CTRWIN_OBJPTR -> GetMonitorBySeqId( (pMonData+ cnt)->nInputOrder, (pMonData+ cnt)->bySpringNo, &MonitorItem );
			if(ret != 1)
				bSpringPass = 1;   //必須要上傳電文項目	 
		    CTRWIN_OBJPTR->UnLock();
		}
/*		if (TRUE == GetTeiseiAddInfo())  //訂正時spring上行電文flag反轉
		{
			if((pMonData + cnt)->szIdNo[0] != NULL)
				if((pMonData + cnt)->byProhibitTel == 0x01)
					(pMonData + cnt)->byProhibitTel = 0;
				else
				{
					if(bSpringPass)
						(pMonData + cnt)->byProhibitTel = 0;        //必須要上傳電文項目,不修改上行電文flag	 
					else
						(pMonData + cnt)->byProhibitTel = 1;
				}
		}
        //ended by TonyChen for現金處理機 990125
*/
	    //  開始編輯電文
		if((pMonData + cnt)->byProhibitTel != 0x01 && (pMonData + cnt)->byProhibitTel != 'A' && (pMonData + cnt)->szTelNo[0] != 0x00 )  //非禁止作成上行電文之項目
		{
			
			CopyMemory(&sToHost[place], (pMonData + cnt)->szTelNo, 3);

			place += 3;

			

			byInputLength = (pMonData + cnt)->byInputLength;

			//是否已輸入小數

			if (byInputLength > 0){



				jisbig.str_bigtojis((pMonData + cnt)->szInput, byInputLength);



				char* point = strchr((pMonData + cnt)->szInput, '.');

				

				if ((pMonData + cnt)->szUserTori3[0] != 'C') { 

					//skip space

					//輸入資料之前的空白不予編入

					for (idx = 0; idx < byInputLength; idx++)

						if ((pMonData + cnt)->szInput[idx] !=0x20)

							break;

					if (byInputLength != idx) //tclmk add for 全部空白

						byInputLength -= idx;

					else

						idx=0;   //tclmk copy inputdata from head

				} //輸入資料之前的空白不清除 20020426



				Length = byInputLength;



				//保留存摺行數,將存摺行數保留(當不用磁條而用手工輸入時使用)

				if (((pMonData + cnt)->szUserTori3[0] == 'B') && (m_wLine == 0)) {

					char M_msline[100];

					memset(M_msline, 0, sizeof(M_msline));

					CopyMemory(M_msline,&(pMonData + cnt)->szInput[idx],Length);

					m_wLine = atoi(M_msline);

				}



				if (point && ((pMonData + cnt)->byDecimalPoint > 0 )){ //add by tclmk

					memset(&strData[0],0,sizeof(strData));

					CopyMemory(strData,&(pMonData + cnt)->szInput[idx],Length);

					char* pointDot = strchr(strData, '.');

					for (int appcnt=1;appcnt <= ((pMonData + cnt)->byDecimalPoint);appcnt++) {

						if (*(pointDot+appcnt) == 0)

							*(pointDot+appcnt) = 0x30;	

						if (*(pointDot+appcnt) == 0x20) 

							*(pointDot+appcnt) = 0x30;

					}

					//copy input data

					appcnt=0;

					if (strData[0]== '.') {

						appcnt ++;

						sToHost[place] = 0x30;

						place ++;

					}

					CopyMemory(&sToHost[place], &strData[0], strlen(strData));

					place += strlen(strData);

					Length = strlen(strData) - byInputLength + appcnt;

				}

				else {

					//copy input data

					CopyMemory(&sToHost[place], &(pMonData + cnt)->szInput[idx], Length);

					place += Length;

					Length = 0;

				}



				//上行電文小數部編輯位數

				//若已有輸入小數,則依輸入為準,不再編入

				//否則自動填入 ".0000....."

			

				if (!point && (pMonData + cnt)->byDecimalPoint > 0){

					Length = (pMonData + cnt)->byDecimalPoint  + 1;



					ZeroMemory(Data, sizeof(Data));

					Data[0] = '.';

					memset(&Data[1], 0x30, (pMonData + cnt)->byDecimalPoint);

					CopyMemory(&sToHost[place], &Data[0], Length);



					place += Length;

				}

								



				if ((pMonData + cnt)->byLength){ //上行電文編輯位數(含上行電文小數部編輯位數)

					//輸入資料 + 小數部

					int inputitme = Length + byInputLength;

					int tmplength = 0;

					//若 (輸入資料 + 小數部) < 上行電文編輯位數(定義於畫面輸入項目)

					//則前面補 '0'

					if (((pMonData + cnt)->byLength) > inputitme){

						tmplength = (pMonData + cnt)->byLength - inputitme;

						CopyMemory(&sToHost[place - inputitme + tmplength], &sToHost[place - inputitme], inputitme);

						memset(&sToHost[place - inputitme], 0x30, tmplength);

						place += tmplength;

					}

					//若 (輸入資料 + 小數部) > 上行電文編輯位數(定義於畫面輸入項目)

					//則前面刪除

					else if (((pMonData + cnt)->byLength) < inputitme){

						tmplength = inputitme - (pMonData + cnt)->byLength;

						CopyMemory(&sToHost[place - inputitme], &sToHost[place - inputitme + tmplength], (pMonData + cnt)->byLength);

						place -= tmplength;



					}

				}

				//Spring輸入項目之附加資訊(類似摘要鍵)

				if ((pMonData + cnt)->szIdNo[0] != NULL){

					CopyMemory(&sToHost[place], (pMonData + cnt)->szIdNo, strlen((pMonData + cnt)->szIdNo));
				 	//place += strlen((pMonData + cnt)->szIdNo);
					place += 1;
	                //Added by TonyChen for SpringInput 20090623    
					switch(sToHost[place-1])
					{
					case '1' :      //現金
						sToHost[place-1] = 'A';	
						break;
                   	case '2' :      //轉帳
						sToHost[place-1] = 'B';	
						break;
					case '3' :      //摘要
						sToHost[place-1] = 'D';	
						break;
					case '4' :      //合計
						sToHost[place-1] = 'I';	
						break;
					case '5' :      
 						if(sToHost[place] == '1')       //票據預收
						{
					    springCheckTOTALAmount =  atoi((pMonData + cnt)->szInput);
                        place = place - ((pMonData + cnt)->byInputLength+strlen((pMonData + cnt)->szTelNo)+2);
						}
						else if(sToHost[place] != '1')  //票據入金
						{
						sToHost[place-1] = 'K';	 
						}
						break;
					case '6' :      //匯款
 						if(sToHost[place] == '1')       //匯款現金    
						{
							sToHost[place-1] = 'A';	  
						}
						else if(sToHost[place] != '1')   
						{
					    	sToHost[place-1] = 'B';	    //匯款轉帳
						}
						break;
				    case '7' :      //匯費
 						if(sToHost[place] == '1')       
						{
                            sToHost[place-1] = 'A';	    //匯費現金
						}
						else if(sToHost[place] != '1')   
						{
							sToHost[place-1] = 'B';	    //匯費轉帳
						}
						break;
					case '8' :    //郵電費
						if(sToHost[place] == '1')       
						{
                            sToHost[place-1] = 'A';	    //郵電費現金
						}
						else if(sToHost[place] != '1')   
						{
							sToHost[place-1] = 'B';	    //郵電費轉帳
						}
						break;
					case '9' :                   //更正
					    if(sToHost[place] == '1')  
							sToHost[place-1] = 'A';	//金額訂正
						if(sToHost[place] == '2')  
							sToHost[place-1] = 'B';	//轉帳訂正
						else
							sToHost[place-1] = 'A';
					    break;
					default :
						break;
					}
				}
	     		    //Ended by TonyChen for SpringInput 20090623   
				// 判斷是否為金額欄位(有摘要鍵)

				else if ((pMonData + cnt)->szUserTori3[0] == 'A'){

					cnt++;

					CopyMemory(&sToHost[place], (pMonData + cnt)->szInput, strlen((pMonData + cnt)->szInput));

					switch(sToHost[place]) {

					case '1' : 

						sToHost[place] = 'A';	//現金

						break;

					case '2' : 

						sToHost[place] = 'B';	//轉帳

						break;

					case '3' :

						sToHost[place] = 'D';	//摘要

						break;

					case '4' :

						sToHost[place] = 'I';	//合計

						break;

					case '5' :

						sToHost[place] = 'K';	//票據

						break;

					default :

						break;

					}

					place += strlen((pMonData + cnt)->szInput);

				} else{

					if (byInputLength > 0){

						sToHost[place] = 'Y';	// 暫定 (Y:項目輸入)

						place++;

					}

				}

			} //if (byInputLength > 0)

			// Control Byte 

			// 因無輸入資料判斷是否為金額欄位(有摘要鍵)是則跳過

			else if ((pMonData + cnt)->szUserTori3[0] == 'A'){

					cnt++;

			}

			//Unit Seperator

			sToHost[place] = 0x1F;

			place++;
			}

//		}
        if (FALSE == GetTeiseiAddInfo())
		{
        //  if((pMonData + cnt)->szIdNo[0]== '8'  || (pMonData + cnt)->szIdNo[0]== '9' )
		//	place = place - ((pMonData + cnt)->byInputLength+strlen((pMonData + cnt)->szTelNo)+2);    
		}

	}//for



	//Record Seperator

//	sToHost[place] = 0x1E;

	sToHost[place] = 0;

//	place++;



    *lpdwResultLength = place;

   	// Exit �g���[�X

	COMN_TraceWrite(&wFlag, TRACELEVEL_6,lpszFuncName,0);



   	return OK;

}
