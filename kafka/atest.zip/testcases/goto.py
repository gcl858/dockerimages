import allure

@allure.step("goto_ecif_home")
async def goto_ecif_home() :
    print()
    assert True

@allure.step("goto_ecif_nbt10180_step1")
async def goto_ecif_nbt10180_step1() :
    print()
    assert True
