import time
import pytest
import allure

from testcases.goto import goto_ecif_nbt10180_step1

@pytest.mark.asyncio
@allure.description("執行時間:"+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
@allure.feature("test_ecif_nbt10180_step1_verify_N Feature")
@allure.story("test_ecif_nbt10180_step1_verify_N Story")
async def test_ecif_nbt10180_step1_verify_N() -> None:
    #前置處理
    await goto_ecif_nbt10180_step1()
    
    #功能驗證
    with allure.step("verify_N") : 
        await verify_N()
        assert True

    async def verify_N() :
        print()