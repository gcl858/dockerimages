import time
import pytest
import allure

from testcases.goto import goto_ecif_home

@pytest.mark.asyncio
@allure.description("執行時間:"+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
@allure.feature("test_ecif_home_verify_mng_P Feature")
@allure.story("test_ecif_home_verify_mng_P Story")
async def test_ecif_home_verify_mng_P() -> None:
    #前置處理
    await goto_ecif_home()
    
    #功能驗證
    with allure.step("verify_mng_P") : 
        await verify_mng_P()
        assert True 

    async def verify_mng_P() :
        print()



