import pytest
import allure

@allure.feature("Example Feature")
@allure.story("Example Story")
def test_example():
    assert True
