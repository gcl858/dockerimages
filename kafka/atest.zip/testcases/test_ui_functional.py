import time
import pytest
import allure

@pytest.mark.asyncio
@allure.description("執行時間:"+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
@allure.feature("ecif_home_verify_op_P Feature")
@allure.story("ecif_home_verify_op_P Story")
async def test_ecif_home_verify_op_P() -> None:
    assert True


@pytest.mark.asyncio
@allure.description("執行時間:"+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
@allure.feature("test_ecif_home_verify_mng_P Feature")
@allure.story("test_ecif_home_verify_mng_P Story")
async def test_ecif_home_verify_mng_P() -> None:
    assert True   


@pytest.mark.asyncio
@allure.description("執行時間:"+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
@allure.feature("test_ecif_nbt10180_step1_verify_N Feature")
@allure.story("test_ecif_nbt10180_step1_verify_N Story")
async def test_ecif_nbt10180_step1_verify_N() -> None:
    assert True