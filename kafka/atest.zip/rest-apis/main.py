from datetime import datetime
import queue
from threading import Thread
from fastapi import FastAPI
import asyncio
import pytest
import os
import re
import json
import subprocess

from browser_manager import cleanup_browser

def find_pytest_testcases(directory):
    """
    遍歷目錄，找出包含 pytest 測試案例的文件和測試名稱。

    :param directory: 要檢查的目錄
    :return: 包含測試文件及其測試案例的字典列表
    """
    pytest_files = []

    # 遍歷目錄及其子目錄
    for root, _, files in os.walk(directory):
        for file in files:
            # 僅檢查以 .py 結尾的文件
            if file.endswith(".py") and (file.startswith("test_") or file.endswith("_test.py")):
                file_path = os.path.join(root, file)

                # 檢查文件中是否包含 pytest 測試案例
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # 使用正則表達式查找測試案例
                test_cases = re.findall(r"def (test_[a-zA-Z0-9_]+)\s*\(", content)
                if test_cases:
                    pytest_files.append({
                        "file": file_path,
                        "testcases": test_cases
                    })

    return pytest_files

def output_results_as_json(result):
    """
    將結果輸出為 JSON 格式。

    :param result: 測試文件及其測試案例的字典
    """
    str=json.dumps(result, separators=(',', ':'), ensure_ascii=False)
    print(json.dumps(result, indent=4, ensure_ascii=False))
    return str

# 主程式
if __name__ == "__main__":
    # 指定目錄
    testcases_dir = "./testcases"  # 替換成實際目錄路徑

    # 查找測試案例
    result = find_pytest_testcases(testcases_dir)

    # 輸出結果
    if result:
        output_results_as_json(result)
    else:
        print("未找到任何 pytest 測試案例。")


app = FastAPI()

@app.get("/testcases")
async def read_testcases():
    # 指定目錄
    testcases_dir = "./testcases"  # 替換成實際目錄路徑
    result = find_pytest_testcases(testcases_dir)
    
    # 輸出結果
    if result:
        jsonstr=output_results_as_json(result)
        return result
    else:
        print("未找到任何 pytest 測試案例。")
        return None

# 建立全域的 asyncio.Queue
test_queue = queue.Queue()
test_status = {}  # 記錄每個測試任務的狀態

def pytest_worker():
    print("pytest_worker!!")
    """
    pytest 的背景工作協程，用於從 Queue 中取得測試任務並執行
    """
    while True:
        task_id, test_args =  test_queue.get()
        try:
            test_status[task_id] = {"status": "running", "result": None}
            print(f"Starting pytest for task {task_id} with arguments: {test_args}")
            exit_code = pytest.main(test_args)
            test_status[task_id] = {
                "status": "completed",
                "result": f"Exit code: {exit_code}",
            }
        except Exception as e:
            test_status[task_id] = {"status": "failed", "result": str(e)}
        finally:
            test_queue.task_done()
            # 定義輸入與輸出目錄
            input_dir = f"./allure-results/{task_id}"
            output_dir = f"./allure-reports/{task_id}"

            # 確保目錄存在
            os.makedirs(input_dir, exist_ok=True)
            os.makedirs(output_dir, exist_ok=True)

            # 定義Allure命令
            genhtml_command = [
                "allure",
                "generate",
                input_dir,
                "-o",
                output_dir
            ]

            # chrome open
            chrome_command = [
                "google-chrome",
                "--disable-web-security",
                "--user-data-dir=/tmp/chrome_dev",
                output_dir+"/index.html"
            ]

            try:
                # 執行命令並打印輸出
                subprocess.run(genhtml_command, check=True)
                print(f"Allure報告已生成：{output_dir}")
                subprocess.Popen(chrome_command)
            except subprocess.CalledProcessError as e:
                print(f"執行命令失敗：{e}")
            except FileNotFoundError:
                print("Allure命令未找到，請確保Allure已正確安裝並添加到PATH環境變量中。")


## 啟動 pytest worker，並確保 FastAPI 啟動時背景協程執行
@app.on_event("startup")
async def startup_event():
    # 啟動時執行的程式碼
    print("start pytest_worker !")
    #pytest_worker_task = asyncio.create_task(pytest_worker())
    pytest_worker_thread = Thread(target=pytest_worker)
    pytest_worker_thread.daemon = True  # 设置为守护线程，这样程序退出时会自动结束
    pytest_worker_thread.start()
    

@app.post("/run-tests/")
async def run_tests():
    """
    啟動新的測試任務
    """
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")[:-3]  # Generate timestamp in YYYYMMDDHHMMSSmmm format
    task_id = timestamp  # 為每個測試任務生成唯一的 ID
    # 動態生成 allure-results 路徑，區分每個任務
    allure_results_dir = f"./allure-results/{task_id}"
    os.makedirs(allure_results_dir, exist_ok=True)

    # 包括 pytest 參數
    test_args = [
        f"--alluredir={allure_results_dir}",  # 指定 Allure 結果目錄
        f"./testcases/test_example1.py" ,
        f"./testcases/test_example2.py"
    ]

    test_status[task_id] = {"status": "queued", "result": None}
    test_queue.put((task_id, test_args))
    return {"message": "Test task queued.", "task_id": task_id}

@app.get("/test-status/{task_id}")
async def get_test_status(task_id: str):
    """
    查詢特定測試任務的執行狀態
    """
    status = test_status.get(task_id)
    if not status:
        return {"message": "Task ID not found."}
    return status

@app.get("/all-test-status/")
async def get_all_test_status():
    """
    查詢所有測試任務的執行狀態
    """
    return test_status

# 啟動時執行的程式碼
#print("start pytest_worker !")
#pytest_worker_task = asyncio.create_task(pytest_worker())
"""這是 pytest 的一個鉤子函數，在測試收集開始前執行"""
#import atexit
#atexit.register(lambda: asyncio.get_event_loop().run_until_complete(cleanup_browser()))

