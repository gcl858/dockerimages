PLAYWRIGHT_BROWSERS_PATH=~/.cache/ms-playwright

uvicorn rest-apis.main:app --reload

google-chrome --disable-web-security --user-data-dir=/tmp/chrome_dev ./allure-reports/index.html

curl -X POST http://127.0.0.1:8000/run-tests/ -H "Content-Type: application/json"
curl -X GET http://127.0.0.1:8000/all-test-status/

allure serve ./allure-results/20241223103024606
allure generate ./allure-results/20241223103024606 -o ./allure-reports/20241223103024606

