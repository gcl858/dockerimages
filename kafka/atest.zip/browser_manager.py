import asyncio
from playwright.async_api import async_playwright, Browser, BrowserContext
from typing import Optional

class BrowserManager:
    _instance = None
    _browser: Optional[Browser] = None
    _context: Optional[BrowserContext] = None
    _playwright = None
    _lock = asyncio.Lock()

    @classmethod
    async def get_instance(cls):
        if not cls._instance:
            cls._instance = cls()
            await cls._instance.initialize()
        return cls._instance

    async def initialize(self):
        async with self._lock:
            if not self._browser:
                print("create global browser !")
                self._playwright = await async_playwright().start()
                self._browser = await self._playwright.chromium.launch(
                    headless=False
                )
                self._context = await self._browser.new_context()

    @property
    async def browser(self) -> Browser:
        return self._browser

    @property
    async def context(self) -> BrowserContext:
        return self._context

    async def cleanup(self):
        print("cleanup global browser !")
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

from browser_manager import BrowserManager
async def cleanup_browser():
    manager = await BrowserManager.get_instance()
    await manager.cleanup()